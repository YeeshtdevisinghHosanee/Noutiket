<?php
$file = fopen("config.txt","r");
$count_row=0;
$dt1=date("Y-m-d h:i:s");	

echo '<html><body style="background-color:#E6E6FA" >';
echo '<h2>Blood donation will be held on the 23rd May 2020 at Stanley Kovil from 9:30 a.m to 1:30 p.m.</br>';
echo 'You do not want to queue up in queues? Please collect your e-ticket here.</br>';
echo 'Come on time and present your e-ticket from 1 metre distance away.</br>';
echo 'In case all e-counters are booked, kindly note that, on the day itself, we will also have other counters assisting you.</br>';
echo 'We thank you for your tremendous effort, specially in this crisis.</h2>.</br>';
$f="txt_a";

echo '<form action="prog1.php" method="post" ><table>';
//echo 'Your full name please: <input type="text" name="clicked1['.$f.']" ></br>';
echo '<a style="font-size:50px">Full name: <input style="white-space: normal;height:40;width:500;font-size:30px;" type="text" name="'.$f.'" ></br>';
while(! feof($file))
  {
  //echo fgets($file). "<br />";
  $arr=explode(",",fgets($file));

 // echo "len".sizeof($arr);
  $lena=sizeof($arr);
  
					if ($count_row==6)
					{
						echo '</tr>';
						$count_row=0;
					}
				//	echo "coount"+$count_row;
					if ($count_row==0)
					{
						echo '<tr>';
						
					}
					$o=1;
				  //echo " <br>".$arr[1];
				  $id="";
				  $status="";
				  
				   for ($x = 0; $x < $lena; $x++) 
				   {
							//echo $x." <br>".$arr[$x];
  
							if ($x==8)
							{
								$status=$arr[$x];
								
							}	
  
  
				 }
$ectime=$arr[6];
	$emax_served=$arr[3];
	$eetime=$arr[2];
	
	$newtime_f =date("dmYHis", strtotime($ectime)+($emax_served*60));
	$newtime_f1 =date("d-m-Y H:i:s", strtotime($ectime)+($emax_served*60));
	$endtim_f =date("dmYHis", strtotime($eetime));
	//echo $newtime_f."FFF".$endtim_f;
    if 	($newtime_f<=$endtim_f)
	{
		if (trim($status)=="on")
			
		{	//echo " <br>yes".$arr[2];
		
				echo '<td>';
				echo '<input style="white-space: normal;height:400px;width:400px;font-size:50px;text-align:center;background-color:#3CB371;" type="submit" name="clicked['.$arr[0].';'.$arr[1].';'.$arr[2].';'.$arr[3].';'.$arr[4].';'.$arr[5].';'.$arr[6].';'.$arr[7].';'.$arr[8].']" value="'.$arr[6].' Counter'.$arr[0].' '.$arr[5].'"/>';
				echo '</td>';
				//echo '<td>';
										
				//echo '<input style="white-space: normal;height:200px;width:200px;font-size:25px;text-align:center;background-color:#3CB371;" type="submit" name="clicked['.$arr[0].';'.$arr[1].';'.$arr[2].';'.$arr[3].';'.$arr[4].';'.$arr[5].';'.$arr[6].'.';'.$arr[7].'.';'.$arr[8].']" value="'.$arr[6].' Counter'.$arr[0].' '.$arr[5].'"/>';

				//echo '</td>';
				$count_row=$count_row+1;
			
				
		}	
  
	}
	
	else
		
		{
			echo '<td>';
				echo '<input disabled style="white-space: normal;height:400px;width:400px;font-size:50px;text-align:center;background-color:#3CB371;" type="submit" name="clicked['.$arr[0].';'.$arr[1].';'.$arr[2].';'.$arr[3].';'.$arr[4].';'.$arr[5].';'.$arr[6].';'.$arr[7].';'.$arr[8].']" value="Booked"/>';
				echo '</td>';
			
			
			
		}	










  }
  echo '</table></form>';
	
					echo '</body ></html>';
fclose($file);
?>