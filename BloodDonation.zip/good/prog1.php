<?php
	$selected_val = key($_POST['clicked']);  // Storing Selected Value In Variable
//$name = key($_POST['clicked1']);
$name = trim(strtolower($_POST['txt_a']));
$name = str_replace(' ', '', $name);
$name = str_replace(' ', '', $name);
$name = str_replace(' ', '', $name);
$name = str_replace(' ', '', $name);
$n1=$name.",";
//echo "yes1".$name;
$ch=0;

if ($name<>"")
{
	$ch=3;
}
else
{
	echo "Full name is blank. Reload homepage.";
}	
$arr1=null;
if ($ch==3)
{$ch=5;
	$file = fopen("fileid.txt","r");
	$alllines="";
	while(! feof($file))
	{
  //echo fgets($file). "<br />";
			 
			$res = trim(fgets($file));
			// echo "ddd". $res;
			 $arr1=explode(",",$res);
			// echo "ddd". $arr1[0];
			//if ($res==trim($name))
			//{
				//$ch=4;
			//}
			$lena=sizeof($arr1);
			for ($x = 0; $x < $lena; $x++) 
				   {
							//echo $x." <br>".$arr1[$x];
  
							if ($arr1[$x]==trim($name))
							{
								$ch=4;
								
							}	
  
  
				 }
			
	}
}	

if ($ch==5)
{
	$ch=9;
}
if ($ch==4)
{
	echo "You cannot book twice.";
}	

if ($ch==9)
{

$retrievedval=$selected_val;
	//echo "yes1".$selected_val;
	$array_opt=explode(";",$selected_val);  // split from selected option html [0]- current_criteria id, [1]-  ending time, [2]-  current time, [3]-  current time
	/**echo "</br>yes12".$array_opt[0]; 
		echo "</br>yes".$array_opt[1]; 
			echo "</br>yes".$array_opt[2]; 
				echo "</br>yes".$array_opt[3]; 
					echo "</br>yes".$array_opt[4]; 
						echo "</br>yes".$array_opt[5]; 
							echo "</br>yes".$array_opt[6]; 
								echo "</br>yes".$array_opt[7]; 
									echo "</br>yes".$array_opt[8]; **/
	//echo "yes1".$selected_val;
	//$date2=date("m/d h:i:s");
	/**$idretrieve=$array_opt[0];
	$eetime=$array_opt[1];
	$ectime=$array_opt[2];
	$emax_served=$array_opt[3];
	$ecounter=$array_opt[4];
	$ebid=$array_opt[5];
	$ebranchname=$array_opt[6];
	
	$endingdate =date("Ymd", strtotime($array_opt[1]));
	$todaydate=date("Ymd");**/
	
	
	$endingdate =date("dmY", strtotime($array_opt[2]));
	$todaydate=date("Ymd");
	//echo "</br>endingdate".$endingdate ;
	//echo "</br>todaydate".$todaydate ;
//	echo "</br>id".$idretrieve ;
// echo "</br>endtime".$eetime ;
	//echo "</br>ctime".$ectime ;
	//echo "</br>max served".$emax_served ;
	$ectime=$array_opt[6];
	$emax_served=$array_opt[3];
	$eetime=$array_opt[2];
	//echo "yes1".$selected_val;
	$newtime_f =date("dmYHis", strtotime($ectime)+($emax_served*60));
	$newtime_f1 =date("d-m-Y H:i:s", strtotime($ectime)+($emax_served*60));
	$endtim_f =date("dmYHis", strtotime($eetime));
	

						//echo "</br>yes222".$newtime_f; 
							//echo "</br>yes".$newtime_f1; 
								//echo "</br>yes".$endtim_f; 
									//echo "</br>yes".$array_opt[8]; 
	
	//echo "yes1".$selected_val;
	$file = fopen("config.txt","r");
	$alllines="";
	while(! feof($file))
	{$res = fgets($file);
	   
	   $arr=explode(",",fgets($file));
	    if ($arr[0]==$array_opt[0])
		   {//echo "</br>richa".$res;
			     $res = str_replace( $ectime, $newtime_f1,$res); 
		   }
		    $alllines=$alllines.$res."\n";
	}
	//echo "yes1".$selected_val;
	$file = fopen("config.txt","r");
	$alllines="";
	while(! feof($file))
  {
  //echo fgets($file). "<br />";
			 
			$res = fgets($file);
			$arr=explode(",",$res);
			//  echo "</br>hello".$res;
		 if ($arr[0]==$array_opt[0])
		   {
				  //echo "len>>".$arr[0];
				  $lena=sizeof($arr);
				
				  $res = str_replace( $ectime, $newtime_f1,$res); 
				
		   }
		 $alllines=$alllines.$res;
		 

  
  }

//echo "</br>".$alllines;

if ($retrievedval<>"")
	{
$file = 'config.txt';
// The new person to add to the file

// Write the contents to the file, 
// using the FILE_APPEND flag to append the content to the end of the file
// and the LOCK_EX flag to prevent anyone else writing to the file at the same time
file_put_contents($file, trim($alllines),  LOCK_EX);


$file1 = 'fileid.txt';

file_put_contents($file1, trim($n1), FILE_APPEND | LOCK_EX);





$filepath="./".$array_opt[0]."/ticket".$array_opt[0]."A".$newtime_f.".html";

	//if(!is_file($filepath)){
//$txt_all='<font size="400px" color="blue"><center>'.$newtime_f1.'</br> Counter '.$array_opt[0].'</center></font>';
		$txt_all='<h1 style="font-size:180px"><center>'.$newtime_f1.'</br>Counter '.$array_opt[0].'</br>';
//$txt_all=$txt_all.'<font size="60px" color="blue"><center>ID:'.$array_opt[5].'Counter '.$array_opt[0].'</center></font>';
$txt_all=$txt_all.'<h2 style="font-size:120px">'.$array_opt[5].'</h2>';
	//$txt_all="yes";
	$contents = '<html><body style="background-color:#E6E6FA">'.$txt_all.'</body></html>'; 

		if (file_put_contents($filepath, $contents))
						{
								$filepath1=$array_opt[0]."%2Fticket".$array_opt[0]."A".$newtime_f.".html";
								echo '<p style="font-size :30px; width: 100%; height: 100px;"><a href="qa_download.php?file=' . $filepath1 . '">'.'Download Ticket Here'.'</a></p>';
							
							
	
							
							
						}	
	//}



	}


	
	if ($retrievedval<>"")
	{
	
	/** $filepath="./".$array_opt[0]."/ticket".$$array_opt[0]."A".$$array_opt[7].".html";
				//	echo "<br/>BranchName:".$g_val1;
						//echo $filepath;
						if(!is_file($filepath)){
							//$txt_time='<font size="100px" color="blue"><center>'.$newtime_f1.'>>> Counter '.$ecounter.'</center></font>';
							//$txt_id='<font size="60px" color="blue"><center>ID:'.$g_val1.'A'.$current_cid.'</center></font>';
							 //$txt_1='<font size="10px" color="blue"><center>'.$ecounter.'</center></font>';
							 //$txt_bankname='<font size="20px" color="blue"><center>'.$ebranchname.'</center></font>';
							
							//$txt_time='<h1 style="font-size:180px"><center>'.$newtime_f1.'</br>';
							
							//$txt_id='<a>'.$g_val1.'A'.$current_cid.'-'.$clientid.'    Counter '.$ecounter.'</a>';
							//$txt_bankname='<h2 style="font-size:120px">'.$g_val1.'A'.$current_cid.'-'.$clientid.'@'.$ebranchname.'</h2>';
						   // $txtuser='<h2 style="font-size:120px">'.$user.'@'.$ebranchname.'</h2></center></h1>';
							
							//$txt_all=$txt_time.$txt_id.$txtuser;
													//	$txt_all=$txt_time.$txt_id.$txtuser;
													$txt_all="yes";
									$contents = '<html><body style="background-color:#E6E6FA">'.$txt_all.'</body></html>';           // Some simple example content.
								//file_put_contents($filepath, $contents);     // Save our content to the file.
								
								
								
						
						if (file_put_contents($filepath, $contents))
						{
								$filepath1=$array_opt[0]."%2Fticket".$$array_opt[0]."A".$$array_opt[7].".html";
								echo '<p style="font-size :30px; width: 100%; height: 100px;"><a href="qa_download.php?file=' . $filepath1 . '">'.'Download Ticket Here'.'</a></p>';
							
							
	
							
							
						}	
						}
						**/
	}
}
?>