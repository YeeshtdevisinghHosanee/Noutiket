<?php
require_once 'qa_connection.php';
$g_uid=$_GET['uid'];
$g_docid=$_GET['docid'];
echo "User:".$g_uid  ;

//echo '<font size="2" color="blue" ><p align="right"><a href="qa_mainmenu.php?uid='.$g_uid.'&docid='.$g_docid.'&bid="Unknown"">Back to Main Menu</a></p></font></br>';
 //$filepath="qa_mainmenu.php?uid=".$g_uid."&docid=".$g_docid."&bid="."Unknown";
 $filepath="qa_login.php";
if(isset($_POST['submit'])){
$g_newpassword=$_POST['txt_new'];
$g_password=$_POST['txt_bname'];
$g_check=0;
$g_bid=0;
$g_docid="";

//date_default_timezone_set('Asia/Dubai');
$date = date("Y/m/d");
$dt=date("Y/m/d h:i:s");

$temp="";
$bname="";
$result="";

$db="tbl_superuser";
 $client = new couchClient($url,$db);
  $all_singers = $client->getAllDocs();
  foreach ( $all_singers->rows as $row ) {
   
    $doc = CouchDocument::getInstance($client,$row->id);
	
	$user_id=$doc->_id;
	$user_name=$doc->username;
	$user_password=$doc->password;
	//$user_branch=$doc->branchid;
  
	//echo "<br/>".$user_id;
	//echo "<br/>".$user_name;
	//echo "<br/>".$user_password;
	//echo "<br/>".$user_branch;
	
	if ($user_name==$g_uid)
	{
		
		
		if ($user_password==$g_password)
		{
			$g_check=9;
			//$g_bid=$user_branch;
			$g_docid=$user_id;
			
			$client3 = new couchClient($url,$db);
			$doca = $client3->getDoc($user_id);
						
		
			$doca->password =$g_newpassword;
			try {
							   $client3->storeDoc($doca);
							  echo "</br>Password changed successfully.";
							  
			} catch (Exception $e) {
							   echo "</br>Error: Document storage failed : ".$e->getMessage()."<BR>\n";
			}		
					
					
					
							
							
			
			
		}
		
		
	}	
	
	
   }




 
 if ($g_check==9)
 {
	 //header("Location: qa_mainmenu.php?uid=".$g_uid."&bid=".$g_bid."&docid=".$g_docid);
	 
	 header("Location: ".$filepath);
	 
 }

else
{
	
	echo "</br>Error: Username/Password not found.Try again";
}












}






//$conn->close();

//}
?>

<html>
 <form method="POST">
<font size="20" color="blue"><center><a>Reset superuser password</a></center></font></br>
	<table>
	
	
		<tr>
				<td>Old Password</td>
				<td><input  style="width:200px"       type="password" id="txt_bname" name="txt_bname"      /></td>
		
		</tr>
		
		
		<tr>
				<td>New Password</td>
				<td><input style="width:200px" "type="password" id="txt_new" name="txt_new"       /></td>
		
		</tr>
		
		
		
	
	
		<tr>
				<td><input type="submit"  id="submit" name="submit"   onclick="func_a()"/></td>
		
		</tr>
	
	</table>




</form>

<div id="div_response" style="display:inline">

</div>



</html>