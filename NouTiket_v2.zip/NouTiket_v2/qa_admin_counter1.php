<?php
require_once 'qa_connection.php';

session_start() ;
$g_uid=$_SESSION['username'];
//$g_bid=$_SESSION['password'];
$name=$_SESSION['name'] ;
$g_bid= $_SESSION['branchid'];
 //echo "ss".$g_uid;

	$_SESSION['username']=$g_uid ;
		// $_SESSION['password'] =$g_password;
		 $_SESSION['name'] =$name;
		 	 $_SESSION['branchid'] =$g_bid;

echo "User:".$g_uid."   BranchID:".$g_bid;
$filepath="qa_admin_counter.php";
$check=0;
$selected_val=0;

$db="tbl_counter";
if(isset($_POST['clicked'])){
	$selected_val = key($_POST['clicked']); 
$arra1=explode('-',$selected_val);
$check=1;
if ($check=1)
{
	//$col1=$_POST['col1_'.$selected_val];
	$col2=$_POST['col2_'.$arra1[0].'-'.$arra1[1]];
	$col3=$_POST['col3_'.$arra1[0].'-'.$arra1[1]];
	$doc1=$_POST['doc_'.$arra1[0].'-'.$arra1[2]];
/**	$client3 = new couchClient($url,$db);
	$doca = $client3->getDoc($doc1);
							// updating document
							$doca->fname = $col2;
							$doca->lname = $col3;
							
							try {
							   $client3->storeDoc($doca);
							    header("location:".$filepath);
							} catch (Exception $e) {
							   echo "Document storage failed : ".$e->getMessage()."<BR>\n";
							}
	
	**/
	
	$sql2 = "update tbl_counter set fname='".$col2."' , lname='".$col3."' where id='".$doc1."'";

			
	

			if ($conn->query($sql2) === TRUE) {
				
				 header("location:".$filepath);
			}
			else{
				echo "Error: " . $sql . "<br>" . $conn->error;
				
			}
	
	
	
}

}


if(isset($_POST['clicked1'])){ //delete
	$selected_val = key($_POST['clicked1']); 

$check=1;
if ($check=1)
{
	//$col1=$_POST['col1_'.$selected_val];
	//$col2=$_POST['col2_'.$selected_val];
	//$col3=$_POST['col3_'.$selected_val];
	$doc1=$_POST['doc_'.$selected_val];
	/**$client = new couchClient($url,$db);
	$doc = $client->getDoc($doc1);
	try {
   $client->deleteDoc($doc);
   header("location:".$filepath);
	} 
	catch (Exception $e) {
	echo "Document storage failed : ".$e->getMessage()."<BR>\n";
	}
	**/
	
	$sql2 = "delete from tbl_counter where id='".$doc1."'";

			
	

			if ($conn->query($sql2) === TRUE) {
				
				 header("location:".$filepath);
			}
			else{
				echo "Error: " . $sql . "<br>" . $conn->error;
				
			}
		 
	
}
}

if(isset($_POST['clicked2'])){
	$add = key($_POST['clicked2']); 
	//$add1=$_POST['add1_'.$add];
	$add2=$_POST['add2_'.$add];
	$add3=$_POST['add3_'.$add];
	
	/**echo "</br>".$add;
		//echo "</br>".$add1;
			echo "</br>".$add2;
				echo "</br>".$add3;

	$check=45;
	
	
	
	
				$current_cid=0;
				$g_cid=0;
				
				$client = new couchClient($url,$db);
				
				$all_records = $client->getAllDocs();
				//echo '<select size="1" style="width:400px" width="10" name="txt_bname" id="txt_bname">';
				
				foreach ( $all_records->rows as $row ) {
				   
					$doc = CouchDocument::getInstance($client,$row->id);
					//print_r ($doc);
					$user_bid=$doc->id;
					if ($user_bid>$g_cid)
					{
						$g_cid=$user_bid;
					}
					echo "<br/>".$user_bid;

				 }
				 $current_cid=$g_cid+1;
				 
				 	$prop = new stdClass();
					$prop->_id = "".$current_cid."";
					$prop->id = $current_cid;
					$prop->fname = $add2;
					$prop->lname = $add3;
				


					$doc = new CouchDocument($client);
					if ($doc->set ( $prop ))
					{
						
						
						echo "Insertion completed successfully";
						header("location:".$filepath);
					}
					else
					{
						echo "could not insert record in database";
						
					}	
	
	**/
	
	
		$sql3 = "INSERT INTO tbl_counter (fname,lname)  VALUES ('$add2','$add3')";

			
		//$result1 = mysqli_query($conn, $sql1);

			if ($conn->query($sql3) === TRUE) {
		
			//echo "eee".$g_check1;
	
			
	
						 header("location:".$filepath);
			}	
			
			else{
				echo "Error: " . $sql . "<br>" . $conn->error;
				
			}
	
	
	
	
	
	
	
	
	
	
	
	
	
}




?>


<head>
<title>Test this</title>
</head>
<body>



</body>
</html>