<?php
require_once 'qa_connection.php';
session_start() ;

 $cid=$_SESSION['cid'] ;
	$user=  $_SESSION['username'] ;
	 $fname=  $_SESSION['fname'] ;
	 
	 if ($user<>"")
	 {
	 echo '<font size="3" color="blue" ><p align="right"><a href="qa_client_login.php">Sign out</a></p></font></br>';


	 echo  '<font size="3" color="black">'."Hello, ". $fname."</font> ";
	  echo  '</br></br></br>';
echo '<font size="5" color="black"></br></br>    <a href="qa_client_dversion.php">Booking</a></font>';
echo  '</br>';
echo  '</br>';

	$_SESSION['cid'] = $cid;
	 $_SESSION['username']=$user ;
	   $_SESSION['fname'] = $fname;
	 }
	 
	 
?>

