-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 13, 2020 at 03:34 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_queue`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id` int(11) NOT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `branchid` int(11) NOT NULL,
  `level` varchar(1) NOT NULL,
  `date_created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `username`, `password`, `name`, `branchid`, `level`, `date_created`) VALUES
(5, 'admin', 'password', 'firstuser', 7, 'S', '2020-05-12 17:07:33');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_booking`
--

CREATE TABLE `tbl_booking` (
  `id` int(11) NOT NULL,
  `currentcounter` int(11) NOT NULL,
  `time_assisted` datetime NOT NULL,
  `branchid` int(11) NOT NULL,
  `branch_name` varchar(50) NOT NULL,
  `status` varchar(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `modified_by` varchar(50) NOT NULL,
  `ticketnumber` varchar(50) NOT NULL,
  `clientid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
-- Error reading data for table db_queue.tbl_booking: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `db_queue`.`tbl_booking`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `tbl_branch`
--

CREATE TABLE `tbl_branch` (
  `id` int(11) NOT NULL,
  `bname` varchar(50) NOT NULL,
  `businessid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_branch`
--

INSERT INTO `tbl_branch` (`id`, `bname`, `businessid`) VALUES
(7, 'Super Beau-Bassin', 1),
(8, 'Super Vacoas', 1),
(9, 'Super Flacq', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_client`
--

CREATE TABLE `tbl_client` (
  `id` int(255) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `date_created` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_client`
--

INSERT INTO `tbl_client` (`id`, `username`, `password`, `fname`, `lname`, `date_created`) VALUES
(6, 'nousha', 'nou ', 'nou', 'nou', '2020-05-12'),
(7, 'ano', 'an1 ', 'a', 'a', '2020-05-12');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_counter`
--

CREATE TABLE `tbl_counter` (
  `id` int(11) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_counter`
--

INSERT INTO `tbl_counter` (`id`, `fname`, `lname`) VALUES
(1, 'John', 'jona'),
(3, 'Sara', 'Lona1'),
(4, 'Riche', 'Rini'),
(5, 'Ronda', 'Ronja'),
(6, 'Veel', 'vil'),
(7, 'Roj', 'Rojish'),
(8, 'Ramii', 'Rosh'),
(9, 'Lina', 'Helen');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_counter_criteria`
--

CREATE TABLE `tbl_counter_criteria` (
  `id` int(11) NOT NULL,
  `branchid` int(11) NOT NULL,
  `bcnum` int(11) NOT NULL,
  `maxserved` int(11) NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `currenttime` datetime NOT NULL,
  `counter` int(11) NOT NULL,
  `date_created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_counter_criteria`
--

INSERT INTO `tbl_counter_criteria` (`id`, `branchid`, `bcnum`, `maxserved`, `start_time`, `end_time`, `currenttime`, `counter`, `date_created`) VALUES
(1, 7, 2, 20, '2020-05-07 03:51:00', '2020-05-07 23:51:00', '2020-05-07 03:51:00', 1, '2020-05-07 03:51:00'),
(2, 8, 2, 20, '2020-05-07 03:51:00', '2020-05-07 23:51:00', '2020-05-07 03:51:00', 2, '2020-05-07 03:51:00'),
(4, 9, 2, 20, '2020-05-13 09:00:00', '2020-05-13 23:50:00', '2020-05-13 09:20:00', 3, '2020-05-07 03:51:00'),
(5, 9, 2, 20, '2020-05-13 09:00:00', '2020-05-13 23:50:00', '2020-05-13 09:20:00', 4, '2020-05-07 03:51:00'),
(6, 8, 2, 20, '2020-05-13 09:00:00', '2020-05-13 10:50:00', '2020-05-13 09:00:00', 5, '2020-05-07 03:51:00'),
(7, 8, 2, 20, '2020-05-13 09:00:00', '2020-05-13 16:00:00', '2020-05-13 09:00:00', 4, '2020-05-07 03:51:00'),
(8, 8, 2, 20, '2020-05-13 09:00:00', '2020-05-13 23:50:00', '2020-05-13 17:40:00', 1, '2020-05-07 03:51:00'),
(11, 9, 3, 5, '2020-05-13 22:00:00', '2020-05-13 23:50:00', '2020-05-13 23:50:00', 5, '2020-05-10 16:15:39'),
(12, 7, 1, 20, '2020-05-13 09:00:00', '2020-05-13 23:50:00', '2020-05-13 23:40:00', 5, '2020-05-10 16:16:22'),
(13, 9, 3, 5, '2020-05-13 09:00:00', '2020-05-13 23:50:00', '2020-05-13 09:05:00', 6, '2020-05-10 16:17:08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_booking`
--
ALTER TABLE `tbl_booking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_branch`
--
ALTER TABLE `tbl_branch`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_client`
--
ALTER TABLE `tbl_client`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_counter`
--
ALTER TABLE `tbl_counter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_counter_criteria`
--
ALTER TABLE `tbl_counter_criteria`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_booking`
--
ALTER TABLE `tbl_booking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `tbl_branch`
--
ALTER TABLE `tbl_branch`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_client`
--
ALTER TABLE `tbl_client`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_counter`
--
ALTER TABLE `tbl_counter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_counter_criteria`
--
ALTER TABLE `tbl_counter_criteria`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
