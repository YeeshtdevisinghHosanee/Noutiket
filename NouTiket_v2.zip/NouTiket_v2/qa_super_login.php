<?php
require_once 'qa_connection.php';


if(isset($_POST['submit'])){
$g_uid=$_POST['txt_id'];
$g_password=$_POST['txt_bname'];
$g_check=0;
$g_check2=0;
//$g_bid=0;
$g_docid="";

////date_default_timezone_set('Asia/Dubai');
$date = date("Y/m/d");
$dt=date("Y/m/d h:i:s");

$temp="";
$bname="";
$result="";

$db="tbl_superuser";
/** $client = new couchClient($url,$db);
  $all_singers = $client->getAllDocs();
  foreach ( $all_singers->rows as $row ) {
   
    $doc = CouchDocument::getInstance($client,$row->id);
	
	$user_id=$doc->_id;
	$user_name=$doc->username;
	$user_password=$doc->password;

  
	//echo "<br/>".$user_id;
	//echo "<br/>".$user_name;
	//echo "<br/>".$user_password;
	//echo "<br/>".$user_branch;
	$g_check2=3;
	if ($user_name==$g_uid)
	{
		
		
		if ($user_password==$g_password)
		{
			$g_check=9;
			//$g_bid=$user_branch;
			$g_docid=$user_id;
		}
		
		
	}	
	
	
   }

**/

 $sql="select * from tbl_admin";
$result = mysqli_query($conn, $sql);

			if ($result) {
				//  echo "yes";
				// while($row = mysqli_fetch_array($result)) {
				
					//$g_criteriaid=$row["id"];
					//echo "ff".$g_criteriaid;
				 //}
				$count=0;
			  while($row = mysqli_fetch_array($result)) {
					$g_check1=2;
					$username=$row["username"];
					$password=$row["password"];
					$g_branchid=$row["branchid"];
					$level=$row["level"];
					$id=$row["id"];
					
					if ($username==$g_uid)
					{
						if ($password==MD5($g_password))
						{
						if ($level=="S")
						{
							
							
							
								
						
									 $g_check=9;
								
								
	
						
							
							
						
						}
						}	
					
						
						
						
					}	
					
			  }
			}



 
 if ($g_check==9)
 {
	 header("Location: qa_super_users.php");
	 
	 
 }

else
{
	
	
	echo "Username/Password not correct.";
	
	
	if ($g_check2==0)
	{
		
		echo "Username/Password not correct.";
	
		/**			$g_uid="sadmin";
						//$g_bid="";
						$g_docid="1";
	
					$prop = new stdClass();
					$prop->_id = $g_docid;
					$prop->id =$g_docid;
					$prop->username = $g_uid;
					$prop->password = "password";
					$prop->fname = $g_uid;
					$prop->lname = $g_uid;
				
				
					$doc = new CouchDocument($client);
					if ($doc->set ( $prop ))
					{
						
						header("Location: qa_super_users.php?uid=".$g_uid."&docid=".$g_docid);
						
						
					}
					else
					{
						echo "A problem occured.The system could not insert record in database";
						
					}	
					
					**/
		
	}	
	
	
	
}












}






//$conn->close();

//}
?>

<html>
 <form method="POST">
<font size="20" color="blue"><center><a>Superuser Login Page</a></center></font></br>
	<table>
	
	
		<tr>
				<td>ID</td>
				<td><input style="width:200px" "type="text" id="txt_id" name="txt_id"       /></td>
		
		</tr>
		<tr>
				<td>Password</td>
				<td><input  style="width:200px"       type="password" id="txt_bname" name="txt_bname"      /></td>
		
		</tr>
		
		
		
	
	
		<tr>
				<td><input type="submit"  id="submit" name="submit"   onclick="func_a()"/></td>
		
		</tr>
	
	</table>




</form>

<div id="div_response" style="display:inline">

</div>



</html>