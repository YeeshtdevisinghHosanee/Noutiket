<?php
require_once 'qa_connection.php';
echo '<font size="2" color="blue" ><p align="right"><a href="qa_mainmenu1.php">Back to Main Menu</a></p></font></br>';
session_start() ;
$var_todate=date("Y-m-d H:i:s");

//echo '<td>'.'<input type="submit" name="clicked2['.$x1.']" id="butu_'.$x1.'" value="'.'Branch'.'" </td>';
$g_uid=$_SESSION['username'];
//$g_bid=$_SESSION['password'];
$name=$_SESSION['name'] ;
$g_bid= $_SESSION['branchid'];
$g_super=$_SESSION['checksuper'];
function func_getclientinfo($id,$conn)
 {
	 
	 $sql="select * from tbl_client where id ='".$id."'";
	
	 $result = mysqli_query($conn, $sql);
		$name="";
					if ($result) {
							 while($row = mysqli_fetch_array($result)) {
								 $name=$row['fname'];
								 $name= $name.' '.$row['lname'];
								 
							 }
					}
	 return $name;
 } 
 
 
 function func_getorganisationinfo($id,$conn)
 {
	 
	// $sql="select b2.bname from tbl_business b1,tbl_branch b2 where b1.id=b2.id and b2.id ='".$id."'";
	 $sql="select * from tbl_branch  where  id='".$id."'";
	 $result = mysqli_query($conn, $sql);
		$name="";
		$i="";
		 
		 
					if ($result) {
						//echo "ggg".$name;
							 while($row = mysqli_fetch_array($result)) {
								 $name=$row['bname'];
							   	 $i=$row['businessid'];
								// echo $name;
							 }
							 
							 
							$sql="select id,bname from tbl_business  where  id='".$i."'";
							$result = mysqli_query($conn, $sql);	
							
							if ($result) {
									//echo "ggg".$name;
										 while($row = mysqli_fetch_array($result)) {
											 $name=$name.'@'.$row['bname'];
											
										
										 }
								} 
							 
					}
					
				
					
					
					
	 return $name;
 } 
 
 
 
 
function func_Sorganisation($id1,$conn,$lastrow,$guid)
 {
	 
	echo '<h2>Search Branch Details:</h2>';
	 $sql="select * from tbl_branch where businessid='".$id1."'";
$result = mysqli_query($conn, $sql);
$myarr=array();
			if ($result) {
			 echo '<table border="1">';
	 	 echo '<th>Business ID</th><th>Branch ID</th><th>branch name</th>';
				$count=0;
				
	
			  while($row = mysqli_fetch_array($result)) {
					
					//if ($row["branchid"]==$g_bid)
					//{
					$d=$row["id"];
					$d1=$row["bname"];
					$myarr[$count]=$d;
					$count=$count+1;
					
					echo '<tr>'.
					'<td>'.
					 $id1.
					 '</td>'.
					 '<td>'.
					 $d.
					 '</td>'.
					 '<td>'.
					 $d1.
					 '</td>'.
					 '</tr>';
					 
					 
					
				
			  }
			  
			  echo '</table>';
			  
			  }
			  
			  
			  
	$crec=$lastrow;		  
	echo '<h2>Counter Details:</h2>';		
for ($i=0;$i<$count;$i++)
{	
			  
			  $sql="select * from tbl_counter where  branchid='".$myarr[$i]."'";

$result = mysqli_query($conn, $sql);

					if ($result) {
					 
						// while($row = mysqli_fetch_array($result)) {
						
							//$g_criteriaid=$row["id"];
							//echo "ff".$g_criteriaid;
						 //}
						$count=0;
						 echo '<table border="1">';
					echo '<th>Branch ID</th><th>Counter ID</th><th>Counter Name</th>';
					  while($row = mysqli_fetch_array($result)) {
							
							$id=$row['id'];
							$name=$row['fname'].' '.$row['lname'];
							echo '<tr>'.
							'<td>'.
							 $myarr[$i].
							 '</td>'.
							 '<td>'.
							 $id.
							 '</td>'.
							 '<td>'.
							 $name.
							 '</td>'.
							 '</tr>';
							
					  }
					  
					  echo '</table>';
					}




	//echo "yes66".$crec;
		//echo '</br></br></br></br>';
	
		

	
		
		for ($x = $lastrow; $x < $crec; $x++) {
			//echo "The number is: $x <br>";
				
			
			
		}



		
				 
	 
 }	 
 
 echo '</table>';
		echo '</td>';

		echo '</td>';
		echo '</tr>';
		echo '</table>';
		echo '</form>';
 
			}
 
 
 
 if ($g_super<>"")
{

//business id
$sql="select * from tbl_business ";
$result = mysqli_query($conn, $sql);

			if ($result) {
				//  echo "yes";
				// while($row = mysqli_fetch_array($result)) {
				
					//$g_criteriaid=$row["id"];
					//echo "ff".$g_criteriaid;
				 //}
				$count=0;
				
				echo '<form  method="post" >';
					echo 	'Organisation: <select id="txt_sel" name="txt_sel" onchange="this.form.submit()">';
					 echo '<option ></option>';
			  while($row = mysqli_fetch_array($result)) {
					
					//if ($row["branchid"]==$g_bid)
					//{
					$d=$row["id"];
					$d1=$row["bname"];
					
			
				
				 echo '<option value="'.$d.'">'.$d1.'</option>';
				 
					
					
					
					}
					echo  '</select>';
					echo '</form>';
			  }					


if(isset($_POST['txt_sel'])){
	$selected_val = $_POST['txt_sel']; 
	//echo "ff".$selected_val;
	
	func_Sorganisation($selected_val,$conn,0,$g_uid);
	
}


			}
?>


<head>
<title>Test this</title>
</head>
<body>



</body>
</html>