
<?php
require_once 'qa_connection.php';
date_default_timezone_set('Asia/Dubai');

echo '<font size="2" color="blue" ><p align="right"><a href="qa_client_login1.php">Main Menu</a></p></font></br>';
$dat=date("Y-m-d");
session_start() ;

	$clientid=$_SESSION['cid'] ;
	$user=  $_SESSION['username'] ;
	$fname=  $_SESSION['fname'] ;
	$branchid=  $_SESSION['branchid'] ;
	 
	// echo $clientid."Hello ". $fname;
$newtime_f1="";

//echo "clicked on".key($_POST['clicked']);

echo '<html><body style="background-color:#E6E6FA" >';
//if(isset($_POST['submit']))
//{
	ini_set('max_execution_time', 300); //300 seconds = 5 minutes
	set_time_limit(300);
	
	
	
	
		$checka=0;
			
				$db22="tbl_clientlog";
				
				
	if  ($user<>"")
	{		$chka=0;

			
				
				  $sql = "select * from tbl_booking where clientid='".$clientid."' and branchid='".$branchid."' and DATE(date_created)='".$dat."'";
				$result = mysqli_query($conn, $sql);

			if ($result) {
			
				$count=0;
			  while($row = mysqli_fetch_array($result)) {
			
					$checka=2;
					
					$clid=$row["clientid"];
					$ctime=$row["time_assisted"];
				
							
					}
					
					
					
				
				
			  }
			 
		
			
				
			 	if ($checka==2)
				{
					
					
					
					
						
							echo "<h1>You already have a booking on ".$ctime."</h1>";
							
						
				}	
				if ($checka==0)
				{
				$result  = mysqli_query($conn,"select * from tbl_booking where clientid='".$clientid."' and DATE(date_created)='".$dat."'");
					$num_rows = mysqli_num_rows($result);

					//echo "$num_rows Rows\n";
						if ($num_rows>=3)
						{
							
							echo "<h1>You cannot book more than three times on a day.</h1>";
							$checka=2;
							
						}
				}
		
				 
				 
				 
	
	
	
	
	
	
	if ($checka==0)
	{
	
	//echo "yupi";
	$selected_val = key($_POST['clicked']);  // Storing Selected Value In Variable

$retrievedval=$selected_val;
	//echo "yes1".$selected_val;
	$array_opt=explode(";",$selected_val);  // split from selected option html [0]- current_criteria id, [1]-  ending time, [2]-  current time, [3]-  current time
	//echo "yes".$array_opt[2]; 
	
	//$date1 =date("Y-m-d H:i:s", strtotime($ectime)+($emax_served*60));
	
	//$date1 =date("Ymd H:i:s", strtotime($array_opt[1]));
	//$date2=date("m/d h:i:s");
	$idretrieve=$array_opt[0];
	$eetime=$array_opt[1];
	$ectime=$array_opt[2];
	$emax_served=$array_opt[3];
	$ecounter=$array_opt[4];
	$ebid=$array_opt[5];
	$ebranchname=$array_opt[6];
	
	$endingdate =date("Ymd", strtotime($array_opt[1]));
	$todaydate=date("Ymd");
	//echo "</br>endingdate".$endingdate ;
	//echo "</br>todaydate".$todaydate ;
//	echo "</br>id".$idretrieve ;
// echo "</br>endtime".$eetime ;
	//echo "</br>ctime".$ectime ;
	//echo "</br>max served".$emax_served ;
	
	
	$newtime_f =date("His", strtotime($ectime)+($emax_served*60));
	//$newtime_f1 =date("d-m-Y H:i:s", strtotime($ectime)+($emax_served*60));
		$newtime_f1 =date("H:i:00", strtotime($ectime)+($emax_served*60));
	$endtim_f =date("His", strtotime($eetime));
		$newtime_f3 =date("d-m-Y H:i:00", strtotime($ectime)+($emax_served*60));
	
	$dt4=date("His");
		$ec =date("His", strtotime($ectime));	
		$dt8=date("H:i:s");	
		//echo $dt4."ee44".$dt8."</br>";				
		if ($dt4>$ec)
		{							
				$newtime_f =date("His", strtotime($dt8)+($emax_served*60));

				$newtime_f1 =date("H:i:00", strtotime($dt8)+($emax_served*60));
				$newtime_f3 =date("d-m-Y H:i:00", strtotime($dt8)+($emax_served*60));
			
									
		}			
	
	
	
	
	
	//echo "</br>endtief".$endtim_f ;
	

		//echo "Selection of date ok.";
		if ($newtime_f>$endtim_f) //new time should not be greater than ending time
		{
			echo "We are sorry.This counter is fully booked. Try another one.";
			
		}	
		else
		{
		
		


				$current_cid=rand(10, 99).$clientid;
				$g_cid=0;
				$db2="tbl_clientlog";
				
	


$dt=date("Y-m-d H:i:s");

//echo "</br>proposed new".$newtime_f1 ;
			
			$tik=$idretrieve."A".$current_cid;
			//$dt=date("Y/m/d H:i:s");
	$sql2 = "INSERT INTO tbl_booking (currentcounter,time_assisted,branchid,branch_name,status,date_created,date_modified,modified_by,ticketnumber,clientid)  VALUES ('$ecounter', '$newtime_f1', '$ebid','$ebranchname','InProgressed','$dt','','','$tik','$clientid')";

	if ($conn->query($sql2) === TRUE) {
			
			
		
			
				$count=0;
			
								
				$g_val1=$idretrieve;
				$g_val2="";
				$g_val3="";
				$g_val4="";
				$g_val5="";
				$g_val6="";
				$g_val7="";
				
		
				
				$sql3="update tbl_counter_criteria set currenttime='".$newtime_f1."' where id='".$idretrieve."'";
				
				$g_check=0;
				
				if ($conn->query($sql3) === TRUE)
				{
					//echo "yes".$newtime_f1;
					$g_check=9;
					
				}	
		
				
				


				 
				 if ($g_check==9)
				 {
					 
					 
					 
					 
					 $filepath="./counters/".$g_val1."/ticket".$g_val1."A".$current_cid.".html";
						if(!is_file($filepath))
						{
							
									$txt_time='<h1 style="font-size:180px"><center>'.$newtime_f3.'</br>';
									
									$txt_id='<a>'.'    Counter '.$ecounter.'</br> ID:'.$g_val1.'A'.$current_cid.'</a>';
									$txtuser='<h2 style="font-size:120px">'.$user.'@'.$ebranchname.'</h2></center></h1>';
									
						
									$txt_all=$txt_time.$txt_id.$txtuser;
									$contents = '<html><body style="background-color:#E6E6FA">'.$txt_all.'</body></html>';           // Some simple example content.
							
								
								
						
							if (file_put_contents($filepath, $contents))
							{
									$filepath1="counters/".$g_val1."%2Fticket".$g_val1."A".$current_cid.".html";
									echo '<p style="font-size :30px; width: 100%; height: 100px;"><a href="qa_download.php?file=' . $filepath1 . '">'.'Download Ticket Here'.'</a></p>';
								
								
		
								
								
							}	
						}
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					
					 
				 }

				else
				{
					
					echo "A technical error occured. Try again.";
				}
								
								
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
			}
			else
			{
				echo "could not insert record into clientlog.";
				
			}	
			
		}	
		
	
	}
	
//}
	echo '</body ></html>';
}			
?>