<?php
require_once 'qa_connection.php';
$dt=date("Y-m-d H:i:s");
session_start() ;
$g_uid=$_SESSION['username'];
//$g_bid=$_SESSION['password'];
$name=$_SESSION['name'] ;
$g_bid= $_SESSION['branchid'];
 //echo "ss".$g_uid;
$g_super=$_SESSION['checksuper'];
	$_SESSION['username']=$g_uid ;
		// $_SESSION['password'] =$g_password;
		 $_SESSION['name'] =$name;
		 	 $_SESSION['branchid'] =$g_bid;

echo '<font size="2" color="blue" ><p align="right"><a href="qa_mainmenu1.php">Back to Main Menu</a></p></font></br>';
if ($g_super<>"")
{ 
$chk1=0;
$files = glob('counters'.'/*'.'/*'); // get all file names
foreach($files as $file){ // iterate files
//echo $file;
	$chk1=1;
  if(is_file($file))
  {
    unlink($file); // delete file
	$chk1=2;
  }
}

if ($chk1==1)
{
	echo "Error in deleting files on server";
	
}
	

if ($chk1==2)
{
	echo "Successful deletion of files.";
	
}
	

if ($chk1==0)
{
	echo "No file to delete.";
	
}



function func_delete($conn)
 {
	 
	 $sql="delete from tbl_booking";
	
	 $result = mysqli_query($conn, $sql);
		$name="";
		
		
		
					if ($result) {
						 $sql="ALTER TABLE `tbl_booking` AUTO_INCREMENT=0";
	
						$result = mysqli_query($conn, $sql);
						
						
							if ($result) {
								echo "Successful deletion of records in database.";
							}
							else
							{
								echo "Unsuccessful deletion of records in database.";
							}	
								
						
					}
					else
					{
						echo "Unsuccessful deletion of records in database.";
					}	
					
 }



func_delete($conn);
$conn->close();
//$conn->close();

//}
}
?>

