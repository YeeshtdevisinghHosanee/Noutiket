<?php
require_once 'qa_connection.php';

session_start() ;
$g_uid=$_SESSION['username'];
//$g_bid=$_SESSION['password'];
$name=$_SESSION['name'] ;
$g_bid= $_SESSION['branchid'];
$g_super=$_SESSION['checksuper'];

if ($g_super<>"")
{
// echo "ss".$g_uid;
if ($g_uid<>"")
{
	$_SESSION['username']=$g_uid ;
		// $_SESSION['password'] =$g_password;
		 $_SESSION['name'] =$name;
		 	 $_SESSION['branchid'] =$g_bid;
	
//echo '<font size="2" color="blue" ><p align="right"><a href="qa_super_login.php?uid">Superuser Access</a>         <a href="qa_reset.php">Reset Password</a>   <a href="index.php">                 Log out</a></p></font></br>';
echo '<font size="2" color="blue" ><p align="right"><a href="qa_mainmenu.php">Back to Main Menu</a></p></font></br>';

echo "Welcome user:".$g_uid;
echo "<br/>BranchID:".$g_bid;


$branchname="";
$ecounter="";

$g_val1="";
$g_val2="";
$g_val3="";
$g_val4="";
$g_val5="";
$g_val6="";
$g_val7="";

$g_check=0;
$db="tbl_branch";


$sql="select * from tbl_branch";
$result = mysqli_query($conn, $sql);

			if ($result) {
				//  echo "yes";
				// while($row = mysqli_fetch_array($result)) {
				
					//$g_criteriaid=$row["id"];
					//echo "ff".$g_criteriaid;
				 //}
				$count=0;
			  while($row = mysqli_fetch_array($result)) {
					$g_check1=2;
					$branchid=$row["id"];
				
					
					if ($branchid==$g_bid)
					{
							$g_val2=$row["bname"];
					$g_val3=$row["businessid"];
						
							$g_check=9;
						
						
						
					
						
						
						
					}	
					
			  }
			}


 
 if ($g_check==9)
 {
	// header("Location: qa_mainmenu.php?uid=".$g_uid."&bid=".$g_bid."&docid=".$g_docid);
	 echo "<br/>BranchName:".$g_val2;
	 echo "<br/>BusinessID:".$g_val3;
	 
 }

else
{
	
	echo "Username/Password not correct.";
}
echo  '</br>';
echo '<font size="10" color="blue">SuperUser Manage:</br>  <a href="qa_admin_businessid.php">1.Business</a>   >>>> <a href="qa_admin_branchs.php">2.Branch</a>     >>>>   <a href="qa_admin_counters.php">3.Counter</a>     >>>>   <a href="qa_admin_criterias.php">4.Counter Criteria</a></font>';
echo  '</br>';
echo  '</br>';

echo '</br><font size="10" color="blue">Monitor:</br><a href="qa_admin_monticketss.php">1.Tickets</a></font>';

echo  '</br>';
echo  '</br>';
echo '</br><font size="10" color="blue">Others:'.
'</br><a href="qa_admin_searchs.php">1.Search</a>'.
'</br><a href="qa_super_users.php">2.Admin accounts</a></font>';
echo '<font size="10" color="blue"></br><a href="qa_admin_holiday.php">3.Holidays</a></font>';

echo '<font size="10" color="blue"></br><a href="qa_purge.php">4.Purge Files</a></font>';

//echo '<font size="10" color="blue">Manage:</br><a href="'.header("Location: qa_admin_branch.php?uid=".$g_uid."&bid=".$g_bid."&docid=".$g_docid).'"';

/**
echo '<font size="20" color="blue"><center><a href="qa_form_admin.php">Insert New</a></center></font></br>';

echo '<font size="20" color="blue"><center><a href="update_database.php">Update Existing</a></center></font></br>';
echo '<font size="20" color="blue"><center><a href="delete_database.php">Deleting existing</a></center></font></br>';
echo '<font size="20" color="blue"><center><a href=monitoring.php?bid='.$g_uid.'&ecounter='.$ecounter.'&bname='.$g_bid.'>Monitoring</a></center></font></br>';
echo '<font size="20" color="blue"><center><a href="delete_file.php">Initialise Values</a></center></font></br>';
**/
}
}
?>


<head>
<title>Test this</title>
</head>
<body>



</body>
</html>