<?php
require_once 'qa_connection.php';

session_start() ;
$g_uid=$_SESSION['username'];
//$g_bid=$_SESSION['password'];
$name=$_SESSION['name'] ;
$g_bid= $_SESSION['branchid'];
 //echo "ss".$g_uid;
$g_super=$_SESSION['checksuper'];


 function func_getclientinfo($id,$conn)
 {
	 
	 $sql="select * from tbl_client where id ='".$id."'";
	
	 $result = mysqli_query($conn, $sql);
		$name="";
					if ($result) {
							 while($row = mysqli_fetch_array($result)) {
								 $name=$row['fname'];
								 $name= $name.' '.$row['lname'];
								 
							 }
					}
	 return $name;
 } 
 
 
 
 function func_getorganisationinfo($id,$conn)
 {
	 
	// $sql="select b2.bname from tbl_business b1,tbl_branch b2 where b1.id=b2.id and b2.id ='".$id."'";
	 $sql="select * from tbl_branch  where  id='".$id."'";
	 $result = mysqli_query($conn, $sql);
		$name="";
		$i="";
		 
		 
					if ($result) {
						//echo "ggg".$name;
							 while($row = mysqli_fetch_array($result)) {
								 $name=$row['bname'];
							   	 $i=$row['businessid'];
								// echo $name;
							 }
							 
							 
							$sql="select id,bname from tbl_business  where  id='".$i."'";
							$result = mysqli_query($conn, $sql);	
							
							if ($result) {
									//echo "ggg".$name;
										 while($row = mysqli_fetch_array($result)) {
											 $name=$name.'@'.$row['bname'];
											
										
										 }
								} 
							 
					}
					
				
					
					
					
	 return $name;
 } 
 
 
 function func_search($val,$val2,$val3,$val4,$val5,$gbid,$conn,$g_uid,$lastrow)
{
	// check if fields are blank to decide which query to user in the search process
	
	$chka=array();
	$chka[0]=0;
	$chka[1]=0;
	$chka[2]=0;
	$chka[3]=0;
	$chka[4]=0;

	if ($val=="")
	{
		$chka[0]=1;
		//echo "here1";
	}	
	
	if ($val2=="")
	{
		$chka[1]=1;
		//echo "here2";
	}	
	
	if ($val3=="")
	{
		$chka[2]=1;
		//echo "here3";
	}

	if ($val4=="")
	{
		$chka[3]=1;
		//echo "here3";
	}
	
	if ($val5=="")
	{
		$chka[4]=1;
		//echo "here3";
	}
		
	
	//$dt1=date("Y-m-d");
	$sql="select * from tbl_counter_criteria where  counter='".$val."' order by date_created desc";
	if ($chka[1]==1 && $chka[2]==1 && $chka[3]==1 && $chka[4]==1)
	{
			$sql="select * from tbl_counter_criteria where  counter='".$val."' order by date_created desc";
	}
	
	if ($chka[0]==1 && $chka[2]==1  && $chka[3]==1 && $chka[4]==1)
	{
		//echo "here".$val2;
			$sql="select * from tbl_counter_criteria where  start_time='".$val2."' order by date_created desc";
	}
	
	if ($chka[0]==1 && $chka[1]==1 && $chka[3]==1 && $chka[4]==1)
	{
			$sql="select * from tbl_counter_criteria where  end_time='".$val3."' order by date_created desc";
	}
	
	if ($chka[0]==1 && $chka[1]==1 && $chka[2]==1 && $chka[4]==1)
	{
			$sql="select * from tbl_counter_criteria where  id='".$val4."' order by date_created desc";
	}
	
	if ($chka[0]==1 && $chka[1]==1 && $chka[2]==1 && $chka[3]==1)
	{
			$sql="select * from tbl_counter_criteria where  branchid='".$val5."' order by date_created desc ";
	}
	

	
		$docid=array();
$column1=array();
$column2=array();
$column3=array();
$column4=array();
$column5=array();
$column6=array();
$column7=array();
$column8=array();
$column9=array();
$column10=array();
$column11=array();
$colinfo=array();
		
		$crec=$lastrow;
$g_check=0;
		
		
	
$result = mysqli_query($conn, $sql);

			if ($result) {
				//  echo "yes";
				// while($row = mysqli_fetch_array($result)) {
				
					//$g_criteriaid=$row["id"];
					//echo "ff".$g_criteriaid;
				 //}
				$count=0;
			  while($row = mysqli_fetch_array($result)) {
					
					
					$docid[$crec]=$row["id"];
		$column1[$crec]=$row["id"];
		$column2[$crec]=$row["branchid"];
		$column3[$crec]=$row["bcnum"];
		$column4[$crec]=$row["maxserved"];
		$column5[$crec]=$row["start_time"];
		$column6[$crec]=$row["end_time"];
		$column7[$crec]=$row["currenttime"];
		$column8[$crec]=$row["counter"];
		$column9[$crec]=$row["date_created"];
		$column10[$crec]=$row["date_modified"];
		$colinfo[$crec]=func_getorganisationinfo($row["branchid"],$conn);
					$crec=$crec+1;
						//echo "fff".$row["counter"];
			  }
			}



//echo '</br></br></br></br>';



echo '<h2>Search Results:</h2>';




echo '<form action="qa_admin_criteria1s.php" method="post">';
echo '<table>';
//echo '<tr>';
//echo '<td>';
echo '<table border="1">';


echo '<th><td>Entry ID</td><td>branchid</td><td>Database CounterID</td><td>Serving Time(in Minutes)</td><td>Starting-Time</td><td>Ending-Time</td><td>Current Time</td><td>Branch counter Number</td><td>Date Created</td><td>Date Modified</td><td>Update</td><td>Delete</td></th>';
for ($x = $lastrow; $x < $crec; $x++) {
    //echo "The number is: $x <br>";
	
	
	echo '<tr>';
	echo '<td>'.'<input type="text"  style="width:70px"  name="doc_'.$x.'-'.$docid[$x].'" id="doc_'.$x.'-'.$docid[$x].'" value="'.$docid[$x].'" </td>';
	//echo '<td>'.'<input type="text" style="width:70px"  disabled name="col1_'.$x.'-'.$column1[$x].'-'.$column1[$x].'" id="col1_'.$x.'" value="'.$column1[$x].'" </td>';
	echo '<td>'.'<input type="text" title="'.$colinfo[$x].'" style="width:70px"  name="col2_'.$x.'-'.$column1[$x].'" id="col2_'.$x.'-'.$column1[$x].'" value="'.$column2[$x].'" </td>';
	echo '<td>'.'<input type="text" style="width:130px"  name="col3_'.$x.'-'.$column1[$x].'" id="col3_'.$x.'-'.$column1[$x].'" value="'.$column3[$x].'" </td>';
	echo '<td>'.'<input type="text"   style="width:70px" name="col4_'.$x.'-'.$column1[$x].'" id="col4_'.$x.'-'.$column1[$x].'" value="'.$column4[$x].'" </td>';
	echo '<td>'.'<input type="text" name="col5_'.$x.'-'.$column1[$x].'" id="col5_'.$x.'-'.$column1[$x].'" value="'.$column5[$x].'" </td>';
	echo '<td>'.'<input type="text" name="col6_'.$x.'-'.$column1[$x].'" id="col6_'.$x.'-'.$column1[$x].'" value="'.$column6[$x].'" </td>';
	echo '<td>'.'<input type="text" disabled name="col7_'.$x.'-'.$column1[$x].'" id="col7_'.$x.'-'.$column1[$x].'" value="'.$column7[$x].'" </td>';
		echo '<td>'.'<input type="text" style="width:50px"   name="col8_'.$x.'-'.$column1[$x].'" id="col1_'.$x.'-'.$column1[$x].'" value="'.$column8[$x].'" </td>';
		echo '<td>'.'<input type="text" disabled name="col9_'.$x.'-'.$column1[$x].'" id="col9_'.$x.'-'.$column1[$x].'" value="'.$column9[$x].'" </td>';
		echo '<td>'.'<input type="text" disabled name="col10_'.$x.'-'.$column1[$x].'" id="col10_'.$x.'-'.$column1[$x].'" value="'.$column10[$x].'" </td>';
	
	
	
	echo '<td>'.'<input type="submit" name="clicked['.$x.'-'.$column1[$x].'-'.$docid[$x].']" id="butu_'.$x.'-'.$column1[$x].'" value="'.'update'.'" </td>';
	echo '<td>'.'<input type="submit" name="clicked1['.$x.'-'.$docid[$x].']" id="butd_'.$x.'-'.$docid[$x].'" value="'.'Delete'.'" </td>';
	echo '</tr>';
}



echo '</table>';

echo '</form>';

			
			
	
	
}	
 
 
 
 
 
 
if ($g_super<>"")
{ 
if ($g_uid<>"")
{
	$_SESSION['username']=$g_uid ;
		// $_SESSION['password'] =$g_password;
		 $_SESSION['name'] =$name;
		 	 $_SESSION['branchid'] =$g_bid;
echo "User:".$g_uid."   BranchID:".$g_bid;

echo '<font size="2" color="blue" ><p align="right"><a href="qa_mainmenu1.php">Back to Main Menu</a></p></font></br>';
echo '<h1>Update, delete and add Serving Information</h1>';



echo '<form method="POST"';
echo '<table border="1"';
//echo '<tr>';



	
	

	

//echo '</tr>';
echo '<tr>';
echo '<td>'.' Desk Num: </td>';
echo '<td>'.'<input type="text"  name="txt_dnum" value="" </td>';
echo '<td>'.' Starting Time: </td>';
echo '<td>'.'<input type="text"  name="txt_stime" value="" </td>';
$dt1=date("Y-m-d");

echo '<td>'.' Ending Time:</td>';
echo '<td>'.'<input type="text"  name="txt_etime" value="" </td>';	
echo '<td>'.' ID:</td>';	
echo '<td>'.'<input type="text"  name="txt_id" value="" </td>';	
echo '<td>'.' Branch ID:</td>';	
echo '<td>'.'<input type="text"  name="txt_branchid" value="" </td>';		
echo '<td>'.'<input type="submit" name="clicked4[but_search]" id="but_search" value="'.'Search'.'" </td>';

echo '</tr>';

echo '</table>';


echo '</form>';











$docid=array();
$column1=array();
$column2=array();
$column3=array();
$column4=array();
$column5=array();
$column6=array();
$column7=array();
$column8=array();
$column9=array();
$column10=array();
$colinfo=array();


$crec=0;
$g_check=0;
$db="tbl_counter_criteria";
/**$client = new couchClient($url,$db);
$all_records = $client->getAllDocs();
 foreach ( $all_records->rows as $row ) {
  
    $doc = CouchDocument::getInstance($client,$row->id);
	
	$user_bid=$doc->_id;
	$bid=$doc->id;
	$co3=$doc->branchid;
	$co4=$doc->bcnum;
	$co5=$doc->maxserved;
	$co6=$doc->start_time;
	$co7=$doc->end_time;
	$co8=$doc->current_time;
	$co9=$doc->counter;
	$co10=$doc->date_created;

		$docid[$crec]=$user_bid;
		$column1[$crec]=$bid;
		$column2[$crec]=$co3;
		$column3[$crec]=$co4;
		$column4[$crec]=$co5;
		$column5[$crec]=$co6;
		$column6[$crec]=$co7;
		$column7[$crec]=$co8;
		$column8[$crec]=$co9;
		$column9[$crec]=$co10;
	
		
		$crec=$crec+1;
	
   }

**/

 $sql="select * from tbl_counter_criteria order by date_created,date_modified desc";
 $sql="select * from tbl_counter_criteria order by date_created desc ";
$result = mysqli_query($conn, $sql);

			if ($result) {
				//  echo "yes";
				// while($row = mysqli_fetch_array($result)) {
				
					//$g_criteriaid=$row["id"];
					//echo "ff".$g_criteriaid;
				 //}
				$count=0;
			  while($row = mysqli_fetch_array($result)) {
					
					
					$docid[$crec]=$row["id"];
		$column1[$crec]=$row["id"];
		$column2[$crec]=$row["branchid"];
		$column3[$crec]=$row["bcnum"];
		$column4[$crec]=$row["maxserved"];
		$column5[$crec]=$row["start_time"];
		$column6[$crec]=$row["end_time"];
		$column7[$crec]=$row["currenttime"];
		$column8[$crec]=$row["counter"];
		$column9[$crec]=$row["date_created"];
		$column10[$crec]=$row["date_modified"];
		$colinfo[$crec]=func_getorganisationinfo($row["branchid"],$conn);
					$crec=$crec+1;
					
			  }
			}



//echo '</br></br></br></br>';

if(isset($_POST['clicked4'])){ //delete
	



	$var1=$_POST['txt_dnum'];
	$var2=$_POST['txt_stime'];
	$var3=$_POST['txt_etime'];
	$ID=$_POST['txt_id'];
	$bID=$_POST['txt_branchid'];
	//echo "fff".$var1;
	
	
	
	
	func_search($var1,$var2,$var3,$ID,$bID,$g_bid,$conn,$g_uid,($crec+1));

	
	
	

}

echo '<h2>All Results:</h2>';




echo '<form action="qa_admin_criteria1s.php" method="post">';
echo '<table>';
echo '<tr>';
echo '<td>';
echo '<table border="1">';


echo '<th>Entry ID<td>branchid</td><td>Database CounterID</td><td>Serving Time(in Minutes)</td><td>Starting-Time</td><td>Ending-Time</td><td>Current Time</td><td>Branch counter Number</td><td>Date Created</td><td>Date Modified</td><td>Update</td><td>Delete</td></th>';
for ($x = 0; $x < $crec; $x++) {
    //echo "The number is: $x <br>";
	
	
	echo '<tr>';
	echo '<td>'.'<input type="text"  style="width:50px"  name="doc_'.$x.'-'.$docid[$x].'" id="doc_'.$x.'-'.$docid[$x].'" value="'.$docid[$x].'" </td>';
	//echo '<td>'.'<input type="text" style="width:50px"  disabled name="col1_'.$x.'-'.$column1[$x].'-'.$column1[$x].'" id="col1_'.$x.'" value="'.$column1[$x].'" </td>';
	echo '<td>'.'<input type="text" title="'.$colinfo[$x].'" style="width:50px"  name="col2_'.$x.'-'.$column1[$x].'" id="col2_'.$x.'-'.$column1[$x].'" value="'.$column2[$x].'" </td>';
	echo '<td>'.'<input type="text" style="width:50px"  name="col3_'.$x.'-'.$column1[$x].'" id="col3_'.$x.'-'.$column1[$x].'" value="'.$column3[$x].'" </td>';
	echo '<td>'.'<input type="text"   style="width:50px" name="col4_'.$x.'-'.$column1[$x].'" id="col4_'.$x.'-'.$column1[$x].'" value="'.$column4[$x].'" </td>';
	echo '<td>'.'<input type="text" name="col5_'.$x.'-'.$column1[$x].'" id="col5_'.$x.'-'.$column1[$x].'" value="'.$column5[$x].'" </td>';
	echo '<td>'.'<input type="text" name="col6_'.$x.'-'.$column1[$x].'" id="col6_'.$x.'-'.$column1[$x].'" value="'.$column6[$x].'" </td>';
	echo '<td>'.'<input type="text" disabled name="col7_'.$x.'-'.$column1[$x].'" id="col7_'.$x.'-'.$column1[$x].'" value="'.$column7[$x].'" </td>';
		echo '<td>'.'<input type="text" style="width:50px"   name="col8_'.$x.'-'.$column1[$x].'" id="col1_'.$x.'-'.$column1[$x].'" value="'.$column8[$x].'" </td>';
		echo '<td>'.'<input type="text" disabled name="col9_'.$x.'-'.$column1[$x].'" id="col9_'.$x.'-'.$column1[$x].'" value="'.$column9[$x].'" </td>';
		echo '<td>'.'<input type="text" disabled name="col10_'.$x.'-'.$column1[$x].'" id="col10_'.$x.'-'.$column1[$x].'" value="'.$column10[$x].'" </td>';
	
	
	
	echo '<td>'.'<input type="submit" name="clicked['.$x.'-'.$column1[$x].'-'.$docid[$x].']" id="butu_'.$x.'-'.$column1[$x].'" value="'.'update'.'" </td>';
	echo '<td>'.'<input type="submit" name="clicked1['.$x.'-'.$docid[$x].']" id="butd_'.$x.'-'.$docid[$x].'" value="'.'Delete'.'" </td>';
	echo '</tr>';
}



echo '</table>';
echo '</td>';
echo '<td>';

echo '</form>';
echo '<form action="qa_admin_criteria1s.php" method="post">';
echo '<table border="1">';
//echo '<th><td>Counter ID</td><td>First Name</td><td>Last Name</td><td>add</td></th>';
echo '<th>Docid<td>Entry ID</td><td>branchid</td><td>Database CounterID</td><td>Serving Time(in Minutes)</td><td>Starting-Time</td><td>Ending-Time</td><td>Current Time</td><td>Branch counter Number</td><td>Date Created</td><td>Add</td></th>';

for ($x1 = 0; $x1 < 1; $x1++) {
    //echo "The number is: $x1 <br>";
	
	
	echo '<tr>';
	echo '<td>'.'<input  style="width:50px" type="text"  disabled name="add1_'.$x1.'" id="add1_'.$x1.'" value="auto" </td>';
	echo '<td>'.'<input  style="width:50px" type="text"  disabled name="add2_'.$x1.'" id="add2_'.$x1.'" value="auto" </td>';
	//echo '<td>'.'<input style="width:50px" type="text"  name="add1_'.$x1.'" id="add1_'.$x1.'" value="" </td>';
	
	
	echo '<td><select size="1" style="width:400px" width="10" name="add3_'.$x1.'" id="add3_'.$x1.'">';
			
				
			
					
					 $sql="select * from tbl_branch ";
			$result = mysqli_query($conn, $sql);

			if ($result) {
			
				$count=0;
			  while($row = mysqli_fetch_array($result)) {
					
					
					
					$user_bid=$row["id"];
					$user_branchname=$row["bname"];
				
					
					
			 
			


	
				echo '<option  value="'.$user_bid.'">'.$user_bid.','.$user_branchname.'</option>';
				
				
				 } 
				 }
				
			
		echo	'</select></td>';
	
	
	
	
	
	
	
	
	
	
	
	echo '<td><select size="1" style="width:400px" width="10" name="add4_'.$x1.'" id="add4_'.$x1.'">';
			
				
			

 $sql="select * from tbl_counter order by branchid ";
			$result = mysqli_query($conn, $sql);

			if ($result) {
				//  echo "yes";
				// while($row = mysqli_fetch_array($result)) {
				
					//$g_criteriaid=$row["id"];
					//echo "ff".$g_criteriaid;
				 //}
				$count=0;
			  while($row = mysqli_fetch_array($result)) {
					
					
					
					$user_bid=$row["id"];
					
					$user_branchname=$row["fname"];
					$user_businessid=$row["lname"];
					
					$id1=$row["branchid"];
					
			

				
				
				echo '<option  value="'.$user_bid.'">'.$id1.','.$user_branchname.'</option>';
				 }
			}
				
			
		echo	'</select></td>';
	
	
	
	
	
	
	//echo '<td>'.'<input style="width:50px" type="text"  name="add1_'.$x1.'" id="add1_'.$x1.'" value="" </td>';
	
	
	
			echo '	<td><select name="add5_'.$x1.'" id="add5_'.$x1.'">';
			echo '	  <option value="5">5</option>';
			echo '	  <option value="10">10</option>';
			echo '	  <option value="15">15</option>';
			echo '	  <option value="20">20</option>';
			echo '	   <option value="30">30</option>';
			echo '	    <option value="45">45</option>';
			echo '		 <option value="60">60</option>';
			echo '	</select></td>';
	
	
	
	
	
	
	
	
	echo '<td>'.'<input type="text"  name="add6_'.$x1.'" id="add6_'.$x1.'" value="00:00:00" </td>';
	echo '<td>'.'<input type="text"  name="add7_'.$x1.'" id="add6_'.$x1.'" value="00:00:00" </td>';
	echo '<td>'.'<input type="text" disabled name="add8_'.$x1.'" id="add8_'.$x1.'" value="" </td>';
	
	
	//echo '<td>'.'<input style="width:50px" type="text"  name="add1_'.$x1.'" id="add1_'.$x1.'" value="" </td>';
	
	echo '<td><select id="txt_counter" name="add9_'.$x1.'" id="add9_'.$x1.'">';
		echo '		  <option value="1">1</option>';
			echo '	  <option value="2">2</option>';
			echo '	  <option value="3">3</option>';
			echo '	  <option value="4">4</option>';
			echo '	   <option value="5">5</option>';
			echo '	    <option value="6">6</option>';
			echo '		 <option value="7">7</option>';
			echo '		  <option value="8">10</option>';
			echo '		  <option value="9">11</option>';
			echo '		  <option value="10">12</option>';
			echo '	</select></td>';
		
	
	
	
	
	
	
	
	echo '<td>'.'<input type="text"   disabled name="add10_'.$x1.'" id="add10_'.$x1.'" value="" </td>';

	
	echo '<td>'.'<input type="submit" name="clicked2['.$x1.']" id="butu_'.$x1.'" value="'.'Add'.'" </td>';

	echo '</tr>';
}

echo '</table>';
//echo '</td>';
//echo '</tr>';
echo '</td>';
//echo '</table>';
echo '</form>';

//http://localhost/queueapp/testapp/qa_admin_branch.php








				 }



}

?>


<head>
<title>Test this</title>
</head>
<body>



</body>
</html>