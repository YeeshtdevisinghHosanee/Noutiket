<?php
require_once 'qa_connection.php';

session_start() ;
$g_uid=$_SESSION['username'];
//$g_bid=$_SESSION['password'];
$name=$_SESSION['name'] ;
$g_bid= $_SESSION['branchid'];
 //echo "ss".$g_uid;
  $g_super=$_SESSION['checksuper'];
 function func_getclientinfo($id,$conn)
 {
	 
	 $sql="select * from tbl_client where id ='".$id."'";
	
	 $result = mysqli_query($conn, $sql);
		$name="";
					if ($result) {
							 while($row = mysqli_fetch_array($result)) {
								 $name=$row['fname'];
								 $name= $name.' '.$row['lname'];
								 
							 }
					}
	 return $name;
 } 
 
 
  function func_getorganisationinfo($id,$conn)
 {
	 
	// $sql="select b2.bname from tbl_business b1,tbl_branch b2 where b1.id=b2.id and b2.id ='".$id."'";
	 $sql="select * from tbl_branch  where  id='".$id."'";
	 $result = mysqli_query($conn, $sql);
		$name="";
		$i="";
		 
		 
					if ($result) {
						//echo "ggg".$name;
							 while($row = mysqli_fetch_array($result)) {
								 $name=$row['bname'];
							   	 $i=$row['businessid'];
								// echo $name;
							 }
							 
							 
							$sql="select id,bname from tbl_business  where  id='".$i."'";
							$result = mysqli_query($conn, $sql);	
							
							if ($result) {
									//echo "ggg".$name;
										 while($row = mysqli_fetch_array($result)) {
											 $name=$name.'@'.$row['bname'];
											
										
										 }
								} 
							 
					}
					
				
					
					
					
	 return $name;
 } 
 
 
 function func_search($val,$val2,$val3,$val4,$val5,$gbid,$conn,$g_uid,$lastrow)
{
	// check if fields are blank to decide which query to user in the search process
	
	$chka=array();
	$chka[0]=0;
	$chka[1]=0;
	$chka[2]=0;
	$chka[3]=0;
	$chka[4]=0;

	if ($val=="")
	{
		$chka[0]=1;
		//echo "here1";
	}	
	
	if ($val2=="")
	{
		$chka[1]=1;
		//echo "here2";
	}	
	
	if ($val3=="")
	{
		$chka[2]=1;
		//echo "here3";
	}

	if ($val4=="")
	{
		$chka[3]=1;
		//echo "here3";
	}
	
	if ($val5=="")
	{
		$chka[4]=1;
		//echo "here3";
	}
	
	
	$dt1=date("Y-m-d");
	$sql="select * from tbl_booking where  ticketnumber='".$val."'";
	if ($chka[1]==1 && $chka[2]==1 && $chka[3]==1 && $chka[4]==1)
	{
			$sql="select * from tbl_booking where  ticketnumber='".$val."'";
	}
	
	if ($chka[0]==1 && $chka[2]==1  && $chka[3]==1 && $chka[4]==1)
	{
		//echo "here".$val2;
			$sql="select * from tbl_booking where  status='".$val2."'";
	}
	
	if ($chka[0]==1 && $chka[1]==1 && $chka[3]==1 && $chka[4]==1)
	{
			$sql="select * from tbl_booking where  DATE(date_created)='".$dt1."'";
	}
	
	if ($chka[0]==1 && $chka[1]==1 && $chka[2]==1 && $chka[4]==1)
	{
			$sql="select * from tbl_booking where  id='".$val4."'";
	}
	
	if ($chka[0]==1 && $chka[1]==1 && $chka[2]==1 && $chka[3]==1)
	{
			$sql="select * from tbl_booking where  branchid='".$val5."'";
	}
	
	
	
		$docid=array();
$column1=array();
$column2=array();
$column3=array();
$column4=array();
$column5=array();
$column6=array();
$column7=array();
$column8=array();
$column9=array();
$column10=array();
$column11=array();
$colinfo=array();
		
		$crec=$lastrow;
$g_check=0;
		
		
		$result = mysqli_query($conn, $sql);

					if ($result) {
					 
						// while($row = mysqli_fetch_array($result)) {
						
							//$g_criteriaid=$row["id"];
							//echo "ff".$g_criteriaid;
						 //}
						$count=0;
					  while($row = mysqli_fetch_array($result)) {
							
							//if ($row["branchid"]==$g_bid)
							//{
							$docid[$crec]=$row["id"];
				$column1[$crec]=$row["id"];
				$column2[$crec]=$row["currentcounter"];
				$column3[$crec]=$row["time_assisted"];
				$column4[$crec]=$row["branchid"];
				$column5[$crec]=$row["branch_name"];
				$column6[$crec]=$row["status"];
				$column7[$crec]=$row["date_modified"];
				$column8[$crec]=$row["date_created"];
				$column9[$crec]=$row["modified_by"];
					$column10[$crec]=$row["ticketnumber"];
						//$column11[$crec]=$row["clientid"];
						$column11[$crec]=func_getclientinfo($row["clientid"],$conn);
						$colinfo[$crec]=func_getorganisationinfo($row["branchid"],$conn);
							$crec=$crec+1;
							//}
							
					  }
					}


echo '<h2>Search Results:</h2>';

	//echo "yes66".$crec;
		//echo '</br></br></br></br>';
	
		echo '<form action="qa_admin_montickets1s.php" method="post" id="frm_dis1"   name="frm_dis">';
		
		echo '<table>';
		echo '<tr>';
		echo '<td>';
		echo '<table border="1"';

	
		echo '<th><td>Entry ID</td><td>Current counter</td><td>time_assisted</td><td>branchid</td><td>branch_name</td><td>Status</td><td>date_modified</td><td>date_created</td><td>Modify_by</td><td>TicketNum</td><td>ClientNum</td><td>Update</td><td>Delete</td></th>';
		for ($x = $lastrow; $x < $crec; $x++) {
			//echo "The number is: $x <br>";
				
			
			echo '<tr>';
			echo '<td>'.'<input type="text"  style="width:50px"  name="doc_'.$x.'-'.$docid[$x].'" id="doc_'.$x.'-'.$docid[$x].'" value="'.$docid[$x].'" </td>';
			//echo '<td>'.'<input type="text" style="width:70px"  disabled name="col1_'.$x.'-'.$column1[$x].'-'.$column1[$x].'" id="col1_'.$x.'" value="'.$column1[$x].'" </td>';
			echo '<td>'.'<input type="text" style="width:100px" disabled  name="col2_'.$x.'-'.$column1[$x].'" id="col2_'.$x.'-'.$column1[$x].'" value="'.$column2[$x].'" </td>';
			echo '<td>'.'<input type="text" style="width:150px" disabled  name="col3_'.$x.'-'.$column1[$x].'" id="col3_'.$x.'-'.$column1[$x].'" value="'.$column3[$x].'" </td>';
			//echo '<td>'.'<input type="text"   style="width:70px" disabled  name="col4_'.$x.'-'.$column1[$x].'" id="col4_'.$x.'-'.$column1[$x].'" value="'.$column4[$x].'" </td>';
				echo '<td>'.'<input title="'.$colinfo[$x].'" type="text"   style="width:70px" disabled  name="col4_'.$x.'-'.$column1[$x].'" id="col4_'.$x.'-'.$column1[$x].'" value="'.$column4[$x].'" </td>';

			
			echo '<td>'.'<input type="text" style="width:100px"  disabled  name="col5_'.$x.'-'.$column1[$x].'" id="col5_'.$x.'-'.$column1[$x].'" value="'.$column5[$x].'" </td>';
			//echo '<td>'.'<input type="text" style="width:30px" disabled  name="col6_'.$x.'-'.$column1[$x].'" id="col6_'.$x.'-'.$column1[$x].'" value="'.$column6[$x].'" </td>';
			//echo '<td>'.'<input type="text" disabled name="col7_'.$x.'-'.$column1[$x].'" id="col7_'.$x.'-'.$column1[$x].'" value="'.$column7[$x].'" </td>';
				
				$op1=$column6[$x];
				$op2="Done";
				//echo ($op1=="Done")."option23";
				if ($op1=="Done")
				{
					$op2="InProgressed";
				}		
				
				echo '	<td><select name="col6_'.$x.'-'.$column1[$x].'" id="col6_'.$x.'-'.$column1[$x].'" value="'.$column6[$x].'">';
					echo '	  <option value="'.$column6[$x].'">'.$column6[$x].'</option>';
					echo '	  <option value="'.$op2.'">'.$op2.'</option>';
					
					echo '	</select></td>';
			
			
				
				echo '<td>'.'<input type="text" style="width:150px"  disabled  name name="col7_'.$x.'-'.$column1[$x].'" id="col1_'.$x.'-'.$column1[$x].'" value="'.$column7[$x].'" </td>';
				echo '<td>'.'<input type="text" style="width:150px"  disabled  name name="col8_'.$x.'-'.$column1[$x].'" id="col1_'.$x.'-'.$column1[$x].'" value="'.$column8[$x].'" </td>';
				//echo '<td>'.'<input type="text" disabled name="col9_'.$x.'-'.$column1[$x].'" id="col9_'.$x.'-'.$column1[$x].'" value="'.$column9[$x].'" </td>';
				echo '<td>'.'<input type="text" disabled style="width:70px" name="col9_'.$x.'-'.$column1[$x].'" id="col9_'.$x.'-'.$column1[$x].'" value="'.$g_uid.'" </td>';
			echo '<td>'.'<input type="text" disabled name="col10_'.$x.'-'.$column1[$x].'" id="col10_'.$x.'-'.$column1[$x].'" value="'.$column10[$x].'" </td>';
			
			echo '<td>'.'<input type="text" disabled name="col11_'.$x.'-'.$column1[$x].'" id="col11_'.$x.'-'.$column1[$x].'" value="'.$column11[$x].'" </td>';
			
			
			echo '<td>'.'<input type="submit" name="clicked['.$x.'-'.$column1[$x].'-'.$docid[$x].']" id="butu_'.$x.'-'.$column1[$x].'" value="'.'update'.'" </td>';
			echo '<td>'.'<input type="submit" name="clicked1['.$x.'-'.$docid[$x].']" id="butd_'.$x.'-'.$docid[$x].'" value="'.'Delete'.'" </td>';
			echo '</tr>';
		}



		echo '</table>';
		echo '</td>';

		echo '</td>';
		echo '</tr>';
		echo '</table>';
		echo '</form>';
			
			
	
	
}	
 
 
 function func_Sorganisation($id1,$conn,$lastrow,$guid)
 {
	 $sql="select * from tbl_branch where businessid='".$id1."'";
$result = mysqli_query($conn, $sql);
$myarr=array();
			if ($result) {
				//  echo "yes";
				// while($row = mysqli_fetch_array($result)) {
				
					//$g_criteriaid=$row["id"];
					//echo "ff".$g_criteriaid;
				 //}
				$count=0;
				
	
			  while($row = mysqli_fetch_array($result)) {
					
					//if ($row["branchid"]==$g_bid)
					//{
					$d=$row["id"];
					$d1=$row["bname"];
					$myarr[$count]=$d;
					$count=$count+1;
					
				
			  }
			  
			  }
	$crec=$lastrow;		  
			
for ($i=0;$i<$count;$i++)
{	
			  
			  $sql="select * from tbl_booking where  branchid='".$myarr[$i]."'";

$result = mysqli_query($conn, $sql);

					if ($result) {
					 
						// while($row = mysqli_fetch_array($result)) {
						
							//$g_criteriaid=$row["id"];
							//echo "ff".$g_criteriaid;
						 //}
						$count=0;
					  while($row = mysqli_fetch_array($result)) {
							
							//if ($row["branchid"]==$g_bid)
							//{
							$docid[$crec]=$row["id"];
				$column1[$crec]=$row["id"];
				$column2[$crec]=$row["currentcounter"];
				$column3[$crec]=$row["time_assisted"];
				$column4[$crec]=$row["branchid"];
				$column5[$crec]=$row["branch_name"];
				$column6[$crec]=$row["status"];
				$column7[$crec]=$row["date_modified"];
				$column8[$crec]=$row["date_created"];
				$column9[$crec]=$row["modified_by"];
					$column10[$crec]=$row["ticketnumber"];
						//$column11[$crec]=$row["clientid"];
						$column11[$crec]=func_getclientinfo($row["clientid"],$conn);
						$colinfo[$crec]=func_getorganisationinfo($row["branchid"],$conn);
							$crec=$crec+1;
							//}
							
					  }
					}


echo '<h2>Search Results:</h2>';

	//echo "yes66".$crec;
		//echo '</br></br></br></br>';
	
		echo '<form action="qa_admin_montickets1s.php" method="post" id="frm_dis1"   name="frm_dis">';
		
		echo '<table>';
		echo '<tr>';
		echo '<td>';
		echo '<table border="1"';

	
		echo '<th><td>Entry ID</td><td>Current counter</td><td>time_assisted</td><td>branchid</td><td>branch_name</td><td>Status</td><td>date_modified</td><td>date_created</td><td>Modify_by</td><td>TicketNum</td><td>ClientNum</td><td>Update</td><td>Delete</td></th>';
		for ($x = $lastrow; $x < $crec; $x++) {
			//echo "The number is: $x <br>";
				
			
			echo '<tr>';
			echo '<td>'.'<input type="text"  style="width:50px"  name="doc_'.$x.'-'.$docid[$x].'" id="doc_'.$x.'-'.$docid[$x].'" value="'.$docid[$x].'" </td>';
			//echo '<td>'.'<input type="text" style="width:70px"  disabled name="col1_'.$x.'-'.$column1[$x].'-'.$column1[$x].'" id="col1_'.$x.'" value="'.$column1[$x].'" </td>';
			echo '<td>'.'<input type="text" style="width:100px" disabled  name="col2_'.$x.'-'.$column1[$x].'" id="col2_'.$x.'-'.$column1[$x].'" value="'.$column2[$x].'" </td>';
			echo '<td>'.'<input type="text" style="width:150px" disabled  name="col3_'.$x.'-'.$column1[$x].'" id="col3_'.$x.'-'.$column1[$x].'" value="'.$column3[$x].'" </td>';
			//echo '<td>'.'<input type="text"   style="width:70px" disabled  name="col4_'.$x.'-'.$column1[$x].'" id="col4_'.$x.'-'.$column1[$x].'" value="'.$column4[$x].'" </td>';
				echo '<td>'.'<input title="'.$colinfo[$x].'" type="text"   style="width:70px" disabled  name="col4_'.$x.'-'.$column1[$x].'" id="col4_'.$x.'-'.$column1[$x].'" value="'.$column4[$x].'" </td>';

			
			echo '<td>'.'<input type="text" style="width:100px"  disabled  name="col5_'.$x.'-'.$column1[$x].'" id="col5_'.$x.'-'.$column1[$x].'" value="'.$column5[$x].'" </td>';
			//echo '<td>'.'<input type="text" style="width:30px" disabled  name="col6_'.$x.'-'.$column1[$x].'" id="col6_'.$x.'-'.$column1[$x].'" value="'.$column6[$x].'" </td>';
			//echo '<td>'.'<input type="text" disabled name="col7_'.$x.'-'.$column1[$x].'" id="col7_'.$x.'-'.$column1[$x].'" value="'.$column7[$x].'" </td>';
				
				$op1=$column6[$x];
				$op2="Done";
				//echo ($op1=="Done")."option23";
				if ($op1=="Done")
				{
					$op2="InProgressed";
				}		
				
				echo '	<td><select name="col6_'.$x.'-'.$column1[$x].'" id="col6_'.$x.'-'.$column1[$x].'" value="'.$column6[$x].'">';
					echo '	  <option value="'.$column6[$x].'">'.$column6[$x].'</option>';
					echo '	  <option value="'.$op2.'">'.$op2.'</option>';
					
					echo '	</select></td>';
			
			
				
				echo '<td>'.'<input type="text" style="width:150px"  disabled  name name="col7_'.$x.'-'.$column1[$x].'" id="col1_'.$x.'-'.$column1[$x].'" value="'.$column7[$x].'" </td>';
				echo '<td>'.'<input type="text" style="width:150px"  disabled  name name="col8_'.$x.'-'.$column1[$x].'" id="col1_'.$x.'-'.$column1[$x].'" value="'.$column8[$x].'" </td>';
				//echo '<td>'.'<input type="text" disabled name="col9_'.$x.'-'.$column1[$x].'" id="col9_'.$x.'-'.$column1[$x].'" value="'.$column9[$x].'" </td>';
				echo '<td>'.'<input type="text" disabled style="width:70px" name="col9_'.$x.'-'.$column1[$x].'" id="col9_'.$x.'-'.$column1[$x].'" value="'.$guid.'" </td>';
			echo '<td>'.'<input type="text" disabled name="col10_'.$x.'-'.$column1[$x].'" id="col10_'.$x.'-'.$column1[$x].'" value="'.$column10[$x].'" </td>';
			
			echo '<td>'.'<input type="text" disabled name="col11_'.$x.'-'.$column1[$x].'" id="col11_'.$x.'-'.$column1[$x].'" value="'.$column11[$x].'" </td>';
			
			
			echo '<td>'.'<input type="submit" name="clicked['.$x.'-'.$column1[$x].'-'.$docid[$x].']" id="butu_'.$x.'-'.$column1[$x].'" value="'.'update'.'" </td>';
			echo '<td>'.'<input type="submit" name="clicked1['.$x.'-'.$docid[$x].']" id="butd_'.$x.'-'.$docid[$x].'" value="'.'Delete'.'" </td>';
			echo '</tr>';
		}



		
				 
	 
 }	 
 echo '</table>';
		echo '</td>';

		echo '</td>';
		echo '</tr>';
		echo '</table>';
		echo '</form>';
 
			}
 
 
 
 
 
 
 
 
 
 
 
 if ($g_super<>"")
{ 
 
if($g_uid<>"")
{
	$_SESSION['username']=$g_uid ;
		// $_SESSION['password'] =$g_password;
		 $_SESSION['name'] =$name;
		 	 $_SESSION['branchid'] =$g_bid;
echo "User:".$g_uid."   BranchID:".$g_bid;

echo '<font size="2" color="blue" ><p align="right"><a href="qa_mainmenu1.php">Back to Main Menu</a></p></font></br>';
echo '<h1>Monitor tickets for all branches</h1>';

echo '<form method="POST"';
echo '<table border="1"';
//echo '<tr>';



	
	

	

//echo '</tr>';
echo '<tr>';




echo '<td>'.' Ticket Num: </td>';
echo '<td>'.'<input type="text"  name="txt_tickid" value="" </td>';
echo '<td>'.' Status: </td>';
echo '<td>'.'<input type="text"  name="txt_stat" value="" </td>';
$dt1=date("Y-m-d");

echo '<td>'.' Date:</td>';
echo '<td>'.'<input type="text"  name="txt_date" value="" </td>';	
echo '<td>'.' ID:</td>';	
echo '<td>'.'<input type="text"  name="txt_id" value="" </td>';	
echo '<td>'.' Branch ID:</td>';	
echo '<td>'.'<input type="text"  name="txt_branchid" value="" </td>';		
echo '<td>'.'<input type="submit" name="clicked4[but_search]" id="but_search" value="'.'Search'.'      "</td>&nbsp&nbsp&nbsp</br></br>';



//business id
$sql="select * from tbl_business ";
$result = mysqli_query($conn, $sql);

			if ($result) {
				//  echo "yes";
				// while($row = mysqli_fetch_array($result)) {
				
					//$g_criteriaid=$row["id"];
					//echo "ff".$g_criteriaid;
				 //}
				$count=0;
				
				echo '<form  method="post" >';
					echo 	'Organisation: <select id="txt_sel" name="txt_sel" onchange="this.form.submit()">';
					 echo '<option ></option>';
			  while($row = mysqli_fetch_array($result)) {
					
					//if ($row["branchid"]==$g_bid)
					//{
					$d=$row["id"];
					$d1=$row["bname"];
					
			
				
				 echo '<option value="'.$d.'">'.$d1.'</option>';
				 
					
					
					
					}
					echo  '</select>';
					echo '</form>';
			  }					


echo '</tr>';

echo '</table>';


echo '</form>';
	









$docid=array();
$column1=array();
$column2=array();
$column3=array();
$column4=array();
$column5=array();
$column6=array();
$column7=array();
$column8=array();
$column9=array();
$column10=array();
$column11=array();
$colinfo=array();



$crec=0;
$g_check=0;
$db="tbl_clientlog";
/**$client = new couchClient($url,$db);
$all_records = $client->getAllDocs();
 foreach ( $all_records->rows as $row ) {
  
    $doc = CouchDocument::getInstance($client,$row->id);
	
	$user_bid=$doc->_id;
	$bid=$doc->id;
	$co3=$doc->currentcounter;
	$co4=$doc->time_assisted;
	$co5=$doc->branchid;
	$co6=$doc->branch_name;
	$co7=$doc->path;
	$co8=$doc->status;
	$co9=$doc->date_created;
	$co10=$doc->date_modified;
	$co11=$doc->modified_by;
	$co12=$doc->ticketnumber;

	if ($g_bid==$co5)
	{
		$docid[$crec]=$user_bid;
		$column1[$crec]=$bid;
		$column2[$crec]=$co3;
		$column3[$crec]=$co4;
		$column4[$crec]=$co5;
		$column5[$crec]=$co6;
		$column6[$crec]=$co7;
		$column7[$crec]=$co8;
		$column8[$crec]=$co9;
		$column9[$crec]=$co10;
		$column10[$crec]=$co11;
		$column11[$crec]=$co12;
	
		
		$crec=$crec+1;
	}
	
   }
**/

 $sql="select * from tbl_booking ";
$result = mysqli_query($conn, $sql);

			if ($result) {
				//  echo "yes";
				// while($row = mysqli_fetch_array($result)) {
				
					//$g_criteriaid=$row["id"];
					//echo "ff".$g_criteriaid;
				 //}
				$count=0;
			  while($row = mysqli_fetch_array($result)) {
					
					//if ($row["branchid"]==$g_bid)
					//{
					$docid[$crec]=$row["id"];
		$column1[$crec]=$row["id"];
		$column2[$crec]=$row["currentcounter"];
		$column3[$crec]=$row["time_assisted"];
		$column4[$crec]=$row["branchid"];
		$column5[$crec]=$row["branch_name"];
		$column6[$crec]=$row["status"];
		$column7[$crec]=$row["date_modified"];
		$column8[$crec]=$row["date_created"];
		$column9[$crec]=$row["modified_by"];
			$column10[$crec]=$row["ticketnumber"];
				//$column11[$crec]=;
				
				$column11[$crec]=func_getclientinfo($row["clientid"],$conn);
		
			$colinfo[$crec]=func_getorganisationinfo($row["branchid"],$conn);
					$crec=$crec+1;
					//}
					
			 
			 
			 }
			}

if(isset($_POST['clicked4'])){ //delete
	



	$ticketnum=$_POST['txt_tickid'];
	$statu=$_POST['txt_stat'];
	$currdate=$_POST['txt_date'];
	$ID=$_POST['txt_id'];
	$bID=$_POST['txt_branchid'];
	//echo "fff".$currdate;
	
	
	
	
	func_search($ticketnum,$statu,$currdate,$ID,$bID,$g_bid,$conn,$g_uid,($crec+1));

	
	
	

}

if(isset($_POST['txt_sel'])){
	$selected_val = $_POST['txt_sel']; 
	//echo "ff".$selected_val;
	
	func_Sorganisation($selected_val,$conn,($crec+1),$g_uid);
	
}


echo '<h2>All Results:</h2>';


//echo '</br></br></br></br>';
echo '<form action="qa_admin_montickets1s.php" method="post" id="frm_dis"   name="frm_dis">';
echo '<table>';
echo '<tr>';
echo '<td>';
echo '<table border="1"';


echo '<th><td>Entry ID</td><td>Current counter</td><td>time_assisted</td><td>branchid</td><td>branch_name</td><td>Status</td><td>date_modified</td><td>date_created</td><td>Modify_by</td><td>TicketNum</td><td>Client Name</td><td>Update</td><td>Delete</td></th>';
for ($x = 0; $x < $crec; $x++) {
    //echo "The number is: $x <br>";
	
	
	echo '<tr>';
	echo '<td>'.'<input type="text"  style="width:50px"  name="doc_'.$x.'-'.$docid[$x].'" id="doc_'.$x.'-'.$docid[$x].'" value="'.$docid[$x].'" </td>';
	//echo '<td>'.'<input type="text" style="width:70px"  disabled name="col1_'.$x.'-'.$column1[$x].'-'.$column1[$x].'" id="col1_'.$x.'" value="'.$column1[$x].'" </td>';
	echo '<td>'.'<input type="text" style="width:100px" disabled  name="col2_'.$x.'-'.$column1[$x].'" id="col2_'.$x.'-'.$column1[$x].'" value="'.$column2[$x].'" </td>';
	echo '<td>'.'<input type="text" style="width:150px" disabled  name="col3_'.$x.'-'.$column1[$x].'" id="col3_'.$x.'-'.$column1[$x].'" value="'.$column3[$x].'" </td>';
	echo '<td>'.'<input title="'.$colinfo[$x].'" type="text"   style="width:70px" disabled  name="col4_'.$x.'-'.$column1[$x].'" id="col4_'.$x.'-'.$column1[$x].'" value="'.$column4[$x].'" </td>';
	echo '<td>'.'<input type="text" style="width:100px"  disabled  name="col5_'.$x.'-'.$column1[$x].'" id="col5_'.$x.'-'.$column1[$x].'" value="'.$column5[$x].'" </td>';
	//echo '<td>'.'<input type="text" style="width:30px" disabled  name="col6_'.$x.'-'.$column1[$x].'" id="col6_'.$x.'-'.$column1[$x].'" value="'.$column6[$x].'" </td>';
	//echo '<td>'.'<input type="text" disabled name="col7_'.$x.'-'.$column1[$x].'" id="col7_'.$x.'-'.$column1[$x].'" value="'.$column7[$x].'" </td>';
		
		$op1=$column6[$x];
		$op2="Done";
		//echo ($op1=="Done")."option23";
		if ($op1=="Done")
		{
			$op2="InProgressed";
		}		
		
		echo '	<td><select name="col6_'.$x.'-'.$column1[$x].'" id="col6_'.$x.'-'.$column1[$x].'" value="'.$column6[$x].'">';
			echo '	  <option value="'.$column6[$x].'">'.$column6[$x].'</option>';
			echo '	  <option value="'.$op2.'">'.$op2.'</option>';
			
			echo '	</select></td>';
	
	
		
		echo '<td>'.'<input type="text" style="width:150px"  disabled  name name="col7_'.$x.'-'.$column1[$x].'" id="col1_'.$x.'-'.$column1[$x].'" value="'.$column7[$x].'" </td>';
		echo '<td>'.'<input type="text" style="width:150px"  disabled  name name="col8_'.$x.'-'.$column1[$x].'" id="col1_'.$x.'-'.$column1[$x].'" value="'.$column8[$x].'" </td>';
		//echo '<td>'.'<input type="text" disabled name="col9_'.$x.'-'.$column1[$x].'" id="col9_'.$x.'-'.$column1[$x].'" value="'.$column9[$x].'" </td>';
		echo '<td>'.'<input type="text" disabled style="width:70px" name="col9_'.$x.'-'.$column1[$x].'" id="col9_'.$x.'-'.$column1[$x].'" value="'.$g_uid.'" </td>';
	echo '<td>'.'<input type="text" disabled name="col10_'.$x.'-'.$column1[$x].'" id="col10_'.$x.'-'.$column1[$x].'" value="'.$column10[$x].'" </td>';
	
	echo '<td>'.'<input type="text" disabled name="col11_'.$x.'-'.$column1[$x].'" id="col11_'.$x.'-'.$column1[$x].'" value="'.$column11[$x].'" </td>';
	
	
	echo '<td>'.'<input type="submit" name="clicked['.$x.'-'.$column1[$x].'-'.$docid[$x].']" id="butu_'.$x.'-'.$column1[$x].'" value="'.'update'.'" </td>';
	echo '<td>'.'<input type="submit" name="clicked1['.$x.'-'.$docid[$x].']" id="butd_'.$x.'-'.$docid[$x].'" value="'.'Delete'.'" </td>';
	echo '</tr>';
}



echo '</table>';
echo '</td>';

echo '</td>';
echo '</tr>';
echo '</table>';
echo '</form>';

//http://localhost/queueapp/testapp/qa_admin_branch.php











}


}


?>


<head>
<title>Test this</title>
</head>
<body>



</body>
</html>