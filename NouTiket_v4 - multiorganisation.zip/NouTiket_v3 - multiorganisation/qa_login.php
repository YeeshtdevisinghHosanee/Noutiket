<?php
require_once 'qa_connection.php';

session_start() ;
echo '<font size="2" color="blue" ><p align="right"><a href="index.php">Back to Homepage</a></p></font></br>';
if(isset($_POST['submit'])){
$g_uid=$_POST['txt_id'];
$g_password=$_POST['txt_bname'];
$g_check=0;
$g_check2=0;
$g_bid=0;
$g_docid="";

////date_default_timezone_set('Asia/Dubai');
$date = date("Y/m/d");
$dt=date("Y/m/d h:i:s");
$g_check=0;
$g_check1=0;
$temp="";
$bname="";
$result="";
$g_branchid="";
$g_name="";
$db="tbl_login";
$sql="select * from tbl_admin";
$result = mysqli_query($conn, $sql);

			if ($result) {
				//  echo "yes";
				// while($row = mysqli_fetch_array($result)) {
				
					//$g_criteriaid=$row["id"];
					//echo "ff".$g_criteriaid;
				 //}
				$count=0;
			  while($row = mysqli_fetch_array($result)) {
					$g_check1=2;
					$username=$row["username"];
					$password=$row["password"];
					
					$g_name=$row["name"];
					
					if ($username==$g_uid)
					{
						//echo MD5($g_password)."ddd".$password."</br>";
						if ($password==MD5($g_password))
						{
							$g_branchid=$row["branchid"];
							$g_check=9;
						
						
						}	
					
						
						
						
					}	
					
			  }
			}


if ($g_check==9)
 {
	// header("Location: qa_mainmenu.php?uid=".$g_uid."&bid=".$g_bid."&docid=".$g_docid);
	$_SESSION['username']=$g_uid ;
		
		 $_SESSION['name'] =$g_name;
		 	 $_SESSION['branchid'] =$g_branchid;
			
	 header("Location: qa_mainmenu.php");
	 
	 
 }

else
{
	
	
	//echo "Username/Password not correct.";
	$var_todate=date("Y-m-d H:i:s");
	$chka=0;
	if ($g_check1==0)
	{
		
		$sql3 = "INSERT INTO tbl_business(bname,location,date_created)  VALUES ('Branch1','location1','$var_todate')";

			
		//$result1 = mysqli_query($conn, $sql1);

			if ($conn->query($sql3) === TRUE) {
		
			
	
			$sql3 = "INSERT INTO tbl_branch (bname,location,businessid,date_created)  VALUES ('Branch1','Location1','1','$var_todate')";
//echo "eee".($conn->query($sql3));
			if ($conn->query($sql3) === TRUE) {
			
			echo "eee".$chka;
			$chka=1;
			}
						
			}	
			
			else{
				echo "Error: " . $sql3 . "<br>" . $conn->error;
				
			}
	
		
		
	}	
	
	
	
	
	
	if ($chka==1)
	
	{
		$dt=date("Y-m-d H:i:s");
		$sql1="insert into tbl_admin (username,password,name,branchid,level,data_created) values ('admin','password','first user',1,'S','$dt')";
		//$sql2 = "INSERT INTO tbl_admin (username,password,name,branchid,level,data_created)  VALUES ('admin', 'password', 'firstuser','1','S','$dt')";
		$sql2 = "INSERT INTO tbl_admin (username,password,name,branchid,level,date_created)  VALUES ('admin', MD5('password'), 'firstuser','1','S','$dt')";

			
		//$result1 = mysqli_query($conn, $sql1);

			if ($conn->query($sql2) === TRUE) {
		
			echo "eee".$g_check1;
	
			$_SESSION['username']="admin";
	
		    $_SESSION['name'] ="firstuser";
		 	$_SESSION['branchid'] ="1";
	
		 header("Location: qa_mainmenu.php");
			}	
			
			else{
				echo "Error: " . $sql . "<br>" . $conn->error;
				
			}
	}
else
{

echo "Username/Password not correct.";

}	
	
	
	
}












}






//$conn->close();

//}
?>

<html>
 <form method="POST">
<font size="20" color="blue"><center><a>Admin Login Page</a></center></font></br>
	<table>
	
	
		<tr>
				<td>ID</td>
				<td><input style="width:200px" "type="text" id="txt_id" name="txt_id"       /></td>
		
		</tr>
		<tr>
				<td>Password</td>
				<td><input  style="width:200px"       type="password" id="txt_bname" name="txt_bname"      /></td>
		
		</tr>
		
		
		
	
	
		<tr>
				<td><input type="submit"  id="submit" name="submit"   onclick="func_a()"/></td>
		
		</tr>
	
	</table>




</form>

<div id="div_response" style="display:inline">

</div>



</html>