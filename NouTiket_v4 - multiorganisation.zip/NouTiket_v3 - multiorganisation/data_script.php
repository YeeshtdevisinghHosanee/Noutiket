<?php
require_once 'qa_connection.php';



function func_delete($conn,$tblname)
 {
	 
	 $sql="delete from ".$tblname;
	
	 $result = mysqli_query($conn, $sql);
		$name="";
		
		
		
					if ($result) {
						 $sql="ALTER TABLE `".$tblname."` AUTO_INCREMENT=0";
	
						$result = mysqli_query($conn, $sql);
						
						
							if ($result) {
								echo "Successful deletion of records in database.";
							}
							else
							{
								echo "Unsuccessful deletion of records in database.";
							}	
								
						
					}
					else
					{
						echo "Unsuccessful deletion of records in database.";
					}	
					
 }



func_delete($conn,'tbl_booking');
func_delete($conn,'tbl_admin');
func_delete($conn,'tbl_client');
func_delete($conn,'tbl_counter_criteria');
func_delete($conn,'tbl_counter');
func_delete($conn,'tbl_branch');
func_delete($conn,'tbl_business');





$conn->close();
//$conn->close();

//}
?>

