<?php
require_once('qa_connection.php');
$g_username=$_POST['username'];
$g_password=$_POST['password'];
$g_studid=$_POST['fname'];
$g_lname=$_POST['lname'];

//echo '</br>var1'.$g_username;



$g_check=0;
   
   
   $sql = "select * from tbl_client";
  $result = mysqli_query($conn, $sql);
if ($result) {
	
	$count=0;
  while($row = mysqli_fetch_array($result)) {
        $username  =   $row["username"];
        $password   =   $row["password"];
		
		if ($g_username==$username)
		{
			
				

			$g_check=9;

		}		
	

  }



 if ($g_check==0)
 {
	$dt=date("Y/m/d h:i:s");
	$sql = "INSERT INTO tbl_client (username,password,fname,lname,date_Created)  VALUES ('$g_username', MD5('$g_password'), '$g_studid','$g_lname','$dt')";

	if ($conn->query($sql) === TRUE) {
		
		header("location:index.php");
	}
	else {
		echo "Error: " . $sql . "<br>" . $conn->error;
	}
 }
 else{
	 
	 echo "Username".$g_username." already exists.";
	 
 }

	
	}
?>
