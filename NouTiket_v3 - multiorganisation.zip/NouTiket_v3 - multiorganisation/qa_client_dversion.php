<?php

require_once 'qa_connection.php';
ini_set('max_execution_time', 300); //300 seconds = 5 minutes
date_default_timezone_set('Asia/Dubai');
	set_time_limit(300);
	
	session_start() ;
	 echo '<font size="3" color="blue" ><p align="right">    <a href="qa_client_login1.php">Main Menu</a></p></font></br>';

	$clientid=$_SESSION['cid'] ;
	$user=  $_SESSION['username'] ;
	$fname=  $_SESSION['fname'] ;
	
	$_SESSION['cid']=$clientid  ;
 $_SESSION['username'] =$user;
 $sel_bid=$_GET['brid'];
 $_SESSION['fname'] =$fname;
 $_SESSION['branchid'] =$sel_bid;
 $sel_businame=$_GET['brname'];

 //if(isset($_POST['clicked1']))
 //{
		//$selected_val = key($_POST['clicked1']); 
		//$arra1=explode('-',$selected_val);
		//$sel_bid=$arra1[1];
		//$sel_businame=$arra1[2];
		//$_SESSION['branchid'] =$sel_bid;
// }	
	if  ($user<>"")
	{
	// echo $clientid."Hello ". $fname;
$chk1=0;
if ($clientid=="")
{
	if ($user=="")
	{
			$chk1=2;
	}	
}	

if ($chk1==0)
{		
	
$g_criteriaid="";
$g_counter="";
$g_val1="";
$g_val2="";
$g_val3="";
$g_val4="";
$g_val5="";
$g_val6="";
$g_val7="";

$doc=null;
$count_row=0;
$g_count1=0;
$g_count2=0;
////date_default_timezone_set('Asia/Dubai');
echo '<html><body style="background-color:#E6E6FA" >';
echo '<form action="qa_client_dversion1.php" method="post" >';
//echo '<font size="2" color="blue" ><p align="right"><a href="qa_login.php">Admin login</a></p></font></br>';
echo '<table>';
$db="tbl_counter_criteria where branchid='".$sel_bid."' order by starting_time";
$dt1=date("Y-m-d H:i:s");				
				//$client = new couchClient($url,$db);
				
				//$all_records = $client->getAllDocs();
				//echo '<select size="1" style="width:400px" width="10" name="txt_bname" id="txt_bname">';
				//echo '<select size="1" style="width:400px" height="20px" name="opt_criteriaid" id="opt_criteriaid">';
		  $sql = "select * from tbl_counter_criteria where branchid='".$sel_bid."' order by branchid,counter";
  $result = mysqli_query($conn, $sql);

			if ($result) {
				//  echo "yes";
				// while($row = mysqli_fetch_array($result)) {
				
					//$g_criteriaid=$row["id"];
					//echo "ff".$g_criteriaid;
				 //}
				$count=0;
			  while($row = mysqli_fetch_array($result)) {
			
					$g_criteriaid=$row["id"];
					$g_counter=$row["counter"];
					$g_bid=$row["branchid"];
					$g_endingtime=$row["end_time"];
					$g_currenttim=$row["currenttime"];
					$g_maxserved=$row["maxserved"];
					$g_startingtime=$row["start_time"];
  
				   if ($count_row==3)
					{
						echo '</tr>';
						$count_row=0;
					}
					if ($count_row==0)
					{
						echo '<tr>';
						
					}
				  
				  // echo "ff".$g_criteriaid;
				   
				   $g_endingtime1=date("d-M-yy", strtotime($g_endingtime));
					$db1="tbl_branch";
					 $sql1 = "select * from tbl_branch";
					$result1 = mysqli_query($conn, $sql1);
        
					if ($result1) 
					{
							while($row1 = mysqli_fetch_array($result1)) 
							{
								
								$user_bid=$row1["id"];
								$user_branchname=$row1["bname"];
								$user_businessid=$row1["businessid"];
								
								if ($user_bid==$g_bid)
								{
						
						
						
									$g_check=9;
									$g_val1=$user_bid;
									$g_val2=$user_branchname;
									$g_val3=$user_businessid;
							
						
								}	
								
							}
							
							$endingdate =date("Ymd", strtotime($g_endingtime));
							$todaydate=date("Ymd");
							
								//echo "</br>endingdate".$g_endingtime;
							//echo "</br>today".$todaydate;
							
							$endt =date("His", strtotime($g_endingtime));
							$todayt=date("His");
							
							//echo $todayt;
							$user_branchname=$g_val2;
							//if ($endingdate==$todaydate)  // verify if selection is today's date
							//{
								$g_count1=2;
					
								if ($endt>=$todayt)
								{
										$g_startingtime1=date("His", strtotime($g_startingtime));
											$todaydatetime=date("His");
											
											if ($todaydatetime>=$g_startingtime1)
											{
											
											$newtime_f =date("His", strtotime($g_currenttim)+($g_maxserved*60));
											$newtime_f1 =date("H:i:s", strtotime($g_currenttim)+($g_maxserved*60));
											$endtim_f =date("His", strtotime($g_endingtime));
											$status_availability="Avaliable";
											//echo $newtime_f."FFF".$endtim_f."</br>";
											
											$dt4=date("His");
											$ec =date("His", strtotime($g_currenttim));	
											$dt8=date("H:i:s");	
											//echo $dt4."ee44".$dt8."</br>";				
											if ($dt4>$ec)
											{							
													

													$newtime_f1 =date("H:i:00", strtotime($dt8)+($g_maxserved*60));
													
												
																		
											}		
											
											
											
											if ($newtime_f>$endtim_f) //new time should not be greater than ending time
											{
												$status_availability="Booked";
												
												echo '<td>';
										
												echo '<input style="white-space: normal;height:400px;width:400px;font-size:50px;text-align:center;background-color:#3CB371;" type="submit" name="clicked['.$g_criteriaid.';'.$g_endingtime.';'.$g_currenttim.';'.$g_maxserved.';'.$g_counter.';'.$g_bid.';'.$user_branchname.']"  disabled value="'.$sel_businame.' '.$g_val2.' Counter'.$g_counter.' '.$status_availability.'"/>';

													echo '</td>';
												
											}
											else
											{
												echo '<td>';
										
												//echo '<input style="white-space: normal;height:400px;width:400px;font-size:50px;text-align:center;background-color:#3CB371;" type="submit" name="clicked['.$g_criteriaid.';'.$g_endingtime.';'.$g_currenttim.';'.$g_maxserved.';'.$g_counter.';'.$g_bid.';'.$user_branchname.']" value="'.$sel_businame.' '.$g_val2.' Counter'.$g_counter.' '.$status_availability.' at '.$newtime_f1.'"/>';

												echo '<input style="white-space: normal;height:400px;width:400px;font-size:50px;text-align:center;background-color:#3CB371;" type="submit" name="clicked['.$g_criteriaid.';'.$g_endingtime.';'.$g_currenttim.';'.$g_maxserved.';'.$g_counter.';'.$g_bid.';'.$user_branchname.']" value="'.$sel_businame.' '.$g_val2.'  Counter'.$g_counter.' '.$status_availability.'  '.$g_startingtime.'-'.$g_endingtime.'"/>';

												
												echo '</td>';
												
											}	
																	
											}
											else{
												echo '<td>';
												echo '<input style="white-space: normal;height:400px;width:400px;font-size:50px;text-align:center;background-color:#3CB371;" type="submit" name="clicked['.$g_criteriaid.';'.$g_endingtime.';'.$g_currenttim.';'.$g_maxserved.';'.$g_counter.';'.$g_bid.';'.$user_branchname.']"  disabled value="'.$sel_businame.' '.$g_val2.' Counter'.$g_counter.' '.'opens at '.date("H:i:s", strtotime($g_startingtime)).'"/>';

												echo '</td>';
															}
								}
							else{
							echo '<td>';
								echo '<input style="white-space: normal;height:400px;width:400px;font-size:50px;text-align:center;background-color:#3CB371;" type="submit" name="clicked['.$g_criteriaid.';'.$g_endingtime.';'.$g_currenttim.';'.$g_maxserved.';'.$g_counter.';'.$g_bid.';'.$user_branchname.']"  disabled value="'.$sel_businame.' '.$g_val2.' Counter'.$g_counter.' '.'Already closed at '.date("H:i:s", strtotime($g_endingtime)).'"/>';
							echo '</td>';
								}								
								
								$count_row=$count_row+1;
							//}
						
							//else
							//{
					
								//$g_count2=2;
								//echo "no";
						
							//}	
							
						
						
						
								
						
					}
					
					echo '</form>';
	
					echo '</body ></html>';
					
				if ($g_count1==0 & $g_count2==0)
				{
						//echo 'No counter available for today.';

				}
					
			  } // end of outer loop
			  
			  
			  
			  if ($g_count1==0 & $g_count2==0)
					{
						echo '<h2>No counter available today.</h2>';

				}
			  
			  
			  
			}
				   
			/**
					$g_endingtime1=date("d-M-yy", strtotime($g_endingtime));
					$db1="tbl_branch";
					//$client1 = new couchClient($url,$db1);
					//$all_records1 = $client1->getAllDocs();
					//$doc3 = $client1->asArray()->getDoc($g_bid);
					//echo "here1";
					//print_r($doc3);
					//echo "here2";
					
					
					 $sql = "select * from tbl_branch";
					$result = mysqli_query($conn, $sql);
        
					if ($result) {
				 	
							$count=0;
						while($row = mysqli_fetch_array($result)) {
				
					//$g_criteriaid=$row["id"];
					//$g_counter=$row["counter"];
					
					$user_bid=$row["id"];
					$user_branchname=$row["bname"];
					$user_businessid=$row["businessid"];

					//echo $g_endingtime1."branch<br/>".$user_bid;
					//echo "<br/>".$user_branchname;
					//echo "<br/>".$user_businessid;
					
				
					
					
									

					
					if ($user_bid==$g_bid)
					{
						
						
						
							$g_check=9;
							$g_val1=$user_bid;
							$g_val2=$user_branchname;
							$g_val3=$user_businessid;
								//echo '<option  value="'.$user_bid.'">'.$g_endingtime1.'_'.$g_val2.'-counter'.$g_counter.'</option>';
					
					
						//echo "here".$g_val2;
						
					}	
					
	
					
					}}
				
						//echo '<option  value="'.$g_criteriaid.';'.$g_endingtime.';'.$g_currenttim.';'.$g_maxserved.';'.$g_counter.';'.$g_bid.';'.$user_branchname.'">'.$g_endingtime1.'_'.$user_branchname.'-counter'.$g_counter.'</option>';
				
				 	//echo '</select>';
					
					
				
					$endingdate =date("Ymd", strtotime($g_endingtime));
					$todaydate=date("Ymd");
						//echo "</br>endingdate".$g_endingtime;
					//echo "</br>today".$todaydate;
					
					$endt =date("YmdHis", strtotime($g_endingtime));
					$todayt=date("YmdHis");
					
					
					$user_branchname=$g_val2;
					if ($endingdate==$todaydate)  // verify if selection is today's date
					{	$g_count1=2;
					
						if ($endt>$todayt)
						{
						
											$g_startingtime1=date("YmdHis", strtotime($g_startingtime));
											$todaydatetime=date("YmdHis");
											
											if ($todaydatetime>=$g_startingtime1)
											{
											
											$newtime_f =date("YmdHis", strtotime($g_currenttim)+($g_maxserved*60));
											$endtim_f =date("YmdHis", strtotime($g_endingtime));
											$status_availability="Avaliable";
											
											if ($newtime_f>$endtim_f) //new time should not be greater than ending time
											{
												$status_availability="Booked";
												
												echo '<td>';
										
												echo '<input style="white-space: normal;height:200px;width:200px;font-size:25px;text-align:center;background-color:#C0C0C0;" type="submit" name="clicked['.$g_criteriaid.';'.$g_endingtime.';'.$g_currenttim.';'.$g_maxserved.';'.$g_counter.';'.$g_bid.';'.$user_branchname.']"  disabled value="'.$g_val2.' Counter'.$g_counter.' '.$status_availability.'"/>';

													echo '</td>';
												
											}
											else
											{
												echo '<td>';
										
												echo '<input style="white-space: normal;height:200px;width:200px;font-size:25px;text-align:center;background-color:#3CB371;" type="submit" name="clicked['.$g_criteriaid.';'.$g_endingtime.';'.$g_currenttim.';'.$g_maxserved.';'.$g_counter.';'.$g_bid.';'.$user_branchname.']" value="'.$g_val2.' Counter'.$g_counter.' '.$status_availability.'"/>';

												echo '</td>';
												
											}	
																	
											}
											else{
												echo '<td>';
												echo '<input style="white-space: normal;height:200px;width:200px;font-size:25px;text-align:center;background-color:#C0C0C0;" type="submit" name="clicked['.$g_criteriaid.';'.$g_endingtime.';'.$g_currenttim.';'.$g_maxserved.';'.$g_counter.';'.$g_bid.';'.$user_branchname.']"  disabled value="'.$g_val2.' Counter'.$g_counter.' '.'opens at '.date("H:i:s", strtotime($g_startingtime)).'"/>';

												echo '</td>';
															}
											
						}
						else{
							echo '<td>';
								echo '<input style="white-space: normal;height:200px;width:200px;font-size:25px;text-align:center;background-color:#C0C0C0;" type="submit" name="clicked['.$g_criteriaid.';'.$g_endingtime.';'.$g_currenttim.';'.$g_maxserved.';'.$g_counter.';'.$g_bid.';'.$user_branchname.']"  disabled value="'.$g_val2.' Counter'.$g_counter.' '.'Already closed at '.date("H:i:s", strtotime($g_endingtime)).'"/>';
							echo '</td>';
						}
						
						**/
					/**	
						echo '<td>';
					
					   echo '<input style="white-space: normal;height:200px;width:200px;font-size:25px;text-align:center;" type="submit" name="clicked['.$g_criteriaid.';'.$g_endingtime.';'.$g_currenttim.';'.$g_maxserved.';'.$g_counter.';'.$g_bid.';'.$user_branchname.']" value="'.$user_branchname.' Counter'.$g_counter.' '.$status_availability.'"/>';

						echo '</td>';**/
						$count_row=$count_row+1;
					//}
					//else
				    //{	$g_count2=2;
						//echo "no";
						
					//}	
					
					
			 
					//echo '<input type="submit" name="submit" value="Get Ticket Number" />';
			
				//echo "yes2".$endingdate;
			 // }
			//  }
			 // echo '</table>';
					//echo '</form>';
	
					//echo '</body ></html>';
					
					//if ($g_count1==0 & $g_count2==0)
					//{
						//echo 'No counter available for today.';

					//}
			  
}

else{
	echo '<font size="3" color="black" ><p align="left">Click here to sign up/in to the system.<a href="index.html"> Homepage</a></font>';
}	
						
					
	}	
//}	
?>
