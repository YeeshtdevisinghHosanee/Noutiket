<?php
require_once 'qa_connection.php';

$dt=date("Y-m-d H:i:s");
session_start() ;
$g_uid=$_SESSION['username'];
//$g_bid=$_SESSION['password'];
$name=$_SESSION['name'] ;
$g_bid= $_SESSION['branchid'];
echo "User:".$g_uid;
if ($g_uid<>"")
{
//echo '<font size="2" color="blue" ><p align="right"><a href="qa_super_reset.php?uid='.$g_uid.'&docid='.$g_docid.'">Reset Password</a>     <a href="qa_super_users1.php?uid='.$g_uid.'&docid='.$g_docid.'">Back to Main Menu</a></p></font></br>';
//echo '<font size="2" color="blue" ><p align="right"><a href="qa_super_reset.php?uid='.$g_uid.'&docid='.$g_docid.'">Reset Password</a></p></font></br>';
echo '<font size="2" color="blue" ><p align="right"><a href="qa_mainmenu1.php">Back to Main Menu</a></p></font></br>';

echo '<h1>Update, delete and add agents</h1>';

$docid=array();
$column1=array();
$column2=array();
$column3=array();
$column4=array();
$column5=array();
$column6=array();


$crec=0;
$g_check=0;
$db="tbl_login";
/**$client = new couchClient($url,$db);
$all_records = $client->getAllDocs();
 foreach ( $all_records->rows as $row ) {
  
    $doc = CouchDocument::getInstance($client,$row->id);
	
	$user_bid=$doc->_id;
	$bid=$doc->id;
	$user_username=$doc->username;
	$user_password=$doc->password;
		$fname=$doc->fname;
	$lname=$doc->lname;
	$branchid=$doc->branchid;

		$docid[$crec]=$user_bid;
		$column1[$crec]=$bid;
		$column2[$crec]=$user_username;
		$column3[$crec]=$user_password;
		$column4[$crec]=$fname;
		$column5[$crec]=$lname;
		$column6[$crec]=$branchid;
		
		$crec=$crec+1;
	
   }

**/


   $sql="select * from tbl_admin";
$result = mysqli_query($conn, $sql);

			if ($result) {
				//  echo "yes";
				// while($row = mysqli_fetch_array($result)) {
				
					//$g_criteriaid=$row["id"];
					//echo "ff".$g_criteriaid;
				 //}
				$count=0;
			  while($row = mysqli_fetch_array($result)) {
					
					
					$docid[$crec]=$row["id"];
					$column1[$crec]=$row["id"];
					$column2[$crec]=$row["username"];
					$column3[$crec]=$row["name"];
					$column4[$crec]=$row["branchid"];
					$column5[$crec]=$row["level"];
					$column6[$crec]=$row["date_created"];
					$crec=$crec+1;
					
			  }
			}


echo '</br></br></br></br>';
echo '<form action="qa_super_users1.php" method="post">';
echo '<table>';
echo '<tr>';
echo '<td>';
echo '<table border="1"';


echo '<th><td>Docid</td><td>Agent ID</td><td>Username</td><td>Name</td><td>BranchID</td><td>Level</td><td>Date Created</td><td>Update</td><td>Delete</td></th>';
for ($x = 0; $x < $crec; $x++) {
    //echo "The number is: $x <br>";
	
	
	echo '<tr>';
	echo '<td>'.'<input type="text"  name="doc_'.$x.'-'.$docid[$x].'" id="doc_'.$x.'-'.$docid[$x].'" value="'.$docid[$x].'" </td>';
	echo '<td>'.'<input type="text" disabled name="col1_'.$x.'-'.$column1[$x].'-'.$column1[$x].'" id="col1_'.$x.'" value="'.$column1[$x].'" </td>';
	echo '<td>'.'<input type="text" name="col2_'.$x.'-'.$column1[$x].'" id="col1_'.$x.'-'.$column1[$x].'" value="'.$column2[$x].'" </td>';
	echo '<td>'.'<input type="text" name="col3_'.$x.'-'.$column1[$x].'" id="col1_'.$x.'-'.$column1[$x].'" value="'.$column3[$x].'" </td>';
		echo '<td>'.'<input type="text" name="col4_'.$x.'-'.$column1[$x].'" id="col1_'.$x.'-'.$column1[$x].'" value="'.$column4[$x].'" </td>';
	echo '<td>'.'<input type="text" name="col5_'.$x.'-'.$column1[$x].'" id="col1_'.$x.'-'.$column1[$x].'" value="'.$column5[$x].'" </td>';
	echo '<td>'.'<input type="text" name="col6_'.$x.'-'.$column1[$x].'" id="col1_'.$x.'-'.$column1[$x].'" value="'.$column6[$x].'" </td>';
	
	
	echo '<td>'.'<input type="submit" name="clicked['.$x.'-'.$column1[$x].'-'.$docid[$x].']" id="butu_'.$x.'-'.$column1[$x].'" value="'.'update'.'" </td>';
	echo '<td>'.'<input type="submit" name="clicked1['.$x.'-'.$docid[$x].']" id="butd_'.$x.'-'.$docid[$x].'" value="'.'Delete'.'" </td>';
	echo '</tr>';
}



echo '</table>';
echo '</td>';
echo '<td>';
echo '<table border="1"';
//echo '<th><td>Docid</td><td>Username</td><td>Password</td><td>First Name</td><td>Last Name</td><td>BranchID</td><td>add</td></th>';

echo '<th><td>Docid</td><td>Username</td><td>Password</td><td>Name</td><td>Branch</td><td>Level</td><td>Add</td></th>';

for ($x1 = 0; $x1 < 1; $x1++) {
    //echo "The number is: $x1 <br>";
	
	
	echo '<tr>';
	echo '<td>'.'<input type="text"  disabled name="add1_'.$x1.'" id="add1_'.$x1.'" value="automatic" </td>';
	echo '<td>'.'<input type="text"  name="add2_'.$x1.'" id="add1_'.$x1.'" value="" </td>';
	echo '<td>'.'<input type="password" name="add3_'.$x1.'" id="add1_'.$x1.'" value="" </td>';
	echo '<td>'.'<input type="text"  name="add4_'.$x1.'" id="add4_'.$x1.'" value="" </td>';
	//echo '<td>'.'<input type="text"  name="add5_'.$x1.'" id="add5_'.$x1.'" value="" </td>';
	
		echo '<td><select size="1" style="width:400px" width="10" name="add5_'.$x1.'" id="add5_'.$x1.'">';
		
	 $sql="select * from tbl_branch  ";
			$result = mysqli_query($conn, $sql);

			if ($result) {
				//  echo "yes";
				// while($row = mysqli_fetch_array($result)) {
				
					//$g_criteriaid=$row["id"];
					//echo "ff".$g_criteriaid;
				 //}
				$count=0;
			  while($row = mysqli_fetch_array($result)) {
					
					
					
					$user_bid=$row["id"];
					
					$user_branchname=$row["bname"];
				
					
			 
			

				
				
				echo '<option  value="'.$user_bid.'">'.$user_branchname.'</option>';
				 }
			}
				//echo '</select>';
			
		echo	'</select></td>';
	
	
	
	
	
	//echo '<td>'.'<input type="text"  name="add6_'.$x1.'" id="add6_'.$x1.'" value="" </td>';
	
	
	echo '	<td><select name="add6_'.$x1.'" id="add6_'.$x1.'">';
			echo '	  <option value="N">N</option>';
			echo '	  <option value="S">S</option>';
			echo '	</select></td>';
	
	
	
	echo '<td>'.'<input type="submit" name="clicked2['.$x1.']" id="butu_'.$x1.'" value="'.'Add'.'" </td>';

	echo '</tr>';
}

echo '</table>';
echo '</td>';
echo '</tr>';
echo '</table>';
echo '</form>';

//http://localhost/queueapp/testapp/qa_admin_branch.php












}

?>


<head>
<title>Test this</title>
</head>
<body>



</body>
</html>