<?php
require_once 'qa_connection.php';
session_start() ;
	 
 $cid=$_SESSION['cid'] ;
	$user=  $_SESSION['username'] ;
	 $fname=  $_SESSION['fname'] ;
	 
	 
	 
	 
	 if ($user<>"")
	 {
		 
		 
		  echo '<font size="1" color="blue" ><p align="right">    <a href="qa_client_login1.php">Main Menu</a></p></font></br>';

		 
	 }
		 
		 


	$_SESSION['cid'] = $cid;
	 $_SESSION['username']=$user ;
	   $_SESSION['fname'] = $fname;

	 
?>


<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="a.css">
<style>
body {
  font-family: "Lato", sans-serif;
}

/* Fixed sidenav, full height */
.sidenav {
  height: 100%;
  width: 100%;
  position: fixed;
  z-index: 1;
  top: 30px;
  left: 0;
  background-color: #2ECC71;
  overflow-x: hidden;
  padding-top: 20px;
}

/* Style the sidenav links and the dropdown button */
.sidenav a, .dropdown-btn {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 60px;
  color: #818181;
  display: block;
  border: none;
  background: none;
  width: 100%;
  text-align: center;
  cursor: pointer;
  outline: none;
}

/* On mouse-over */
.sidenav a:hover, .dropdown-btn:hover {
  color: #f1f1f1;
}

/* Main content */
.main {
  margin-left: 200px; /* Same as the width of the sidenav */
  font-size: 20px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

/* Add an active class to the active dropdown button */
.active {
  background-color: green;
  color: white;
}

/* Dropdown container (hidden by default). Optional: add a lighter background color and some left padding to change the design of the dropdown content */
.dropdown-container {
  display: none;
  background-color: #262626;
  padding-left: 8px;
}

/* Optional: Style the caret down icon */
.fa-caret-down {
  float: right;
  padding-right: 8px;
}

/* Some media queries for responsiveness */
@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>
</head>
<body>
 

<div class="sidenav">
  
  <?php



   if ($user<>"")
	 {
			$sql = "select * from tbl_branch where businessid='".$_GET['busid']."'";
		  $result = mysqli_query($conn, $sql);
		if ($result) {
			
			$x=0;
				$count_row=0;
		  while($row = mysqli_fetch_array($result)) {
			  if ($count_row==3)
					{
						echo '</tr>';
						$count_row=0;
					}
				//	echo "coount"+$count_row;
					if ($count_row==0)
					{
						echo '<tr>';
						
					}
			  
			  
				$branchname  =  $row["bname"];
					echo '<tr>';
		  //echo '<a>'.'<input style="white-space: normal;height:400px;width:400px;font-size:50px;text-align:center;background-color:#C0C0C0;" type="submit" name="clicked1['.$x.'-'.$row["id"].'-'.$arra1[2].']" id="butd_'.$x.'" value="'.$branchname.'" </a>';
			
			echo '<a href="qa_client_dversion.php?brid='.$row["id"].'&brname='.$_GET['busname'].'">'.$branchname.'</a>';
			
			echo '</tr>';
			$x=$x+1;
			$count_row=$count_row+1;

		  }

		}

	 }


  ?>
  
</div>



<script>
/* Loop through all dropdown buttons to toggle between hiding and showing its dropdown content - This allows the user to have multiple dropdowns without any conflict */
var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 0; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
  this.classList.toggle("active");
  var dropdownContent = this.nextElementSibling;
  if (dropdownContent.style.display === "block") {
  dropdownContent.style.display = "none";
  } else {
  dropdownContent.style.display = "block";
  }
  });
}
</script>

</body>
</html> 
