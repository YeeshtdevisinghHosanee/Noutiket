<?php
require_once 'qa_connection.php';
$dt=date("Y-m-d H:i:s");
session_start() ;
$g_uid=$_SESSION['username'];
//$g_bid=$_SESSION['password'];
$name=$_SESSION['name'] ;
$g_bid= $_SESSION['branchid'];
 //echo "ss".$g_uid;
if($g_uid<>"")
{
	$_SESSION['username']=$g_uid ;
		// $_SESSION['password'] =$g_password;
		 $_SESSION['name'] =$name;
		 	 $_SESSION['branchid'] =$g_bid;

echo "User:".$g_uid."   BranchID:".$g_bid;
$filepath="qa_admin_monticketss.php?";
$check=0;
$selected_val=0;

$db="tbl_clientlog";
if(isset($_POST['clicked'])){
	$selected_val = key($_POST['clicked']); 
$arra1=explode('-',$selected_val);
$check=1;
if ($check=1)
{
	//$col1=$_POST['col1_'.$selected_val];
	//$col2=$_POST['col2_'.$arra1[0].'-'.$arra1[1]];
	//$col3=$_POST['col3_'.$arra1[0].'-'.$arra1[1]];
	//$col4=$_POST['col4_'.$arra1[0].'-'.$arra1[1]];
	//$col5=$_POST['col5_'.$arra1[0].'-'.$arra1[1]];
	//$col6=$_POST['col6_'.$arra1[0].'-'.$arra1[1]];
	$col6=$_POST['col6_'.$arra1[0].'-'.$arra1[1]];
	//$col8=$_POST['col8_'.$arra1[0].'-'.$arra1[1]];
	//$col9=$_POST['col9_'.$arra1[0].'-'.$arra1[1]];
	$col9=$_POST['col9_'.$arra1[0].'-'.$arra1[1]];
	$doc1=$_POST['doc_'.$arra1[0].'-'.$arra1[2]];
	
	
	
	/**
		echo "</br>".$doc1;
		//echo "</br>first1".$add1;
			echo "</br>first12".$col2;
				echo "</br>first13".$col3;
					echo "</br>first12".$col4;
				echo "</br>first13".$col5;
					echo "</br>first12".$col6;
				echo "</br>first13".$col8;
				//	echo "</br>first12".$add10;
				//echo "</br>first13".$add3;
	
	**/
	
	
	
	
	
	
	/**
	
	
	
	$client3 = new couchClient($url,$db);
	$doca = $client3->getDoc($doc1);
							// updating document
							//$doca->fname = $col2;
							//$doca->lname = $col3;
							
							
							//$doca->_id = "".$current_cid."";
					//$prop->id = $current_cid;
					
					//$doca->_id = "".$current_cid."";
			//$doca->id = $current_cid;
			
			$doca->status = $col7;
			
			$doca->date_modified = $dt;
			$doca->modified_by = $col10;
					
					
					
					
							
							try {
							   $client3->storeDoc($doca);
							    header("location:".$filepath);
							} catch (Exception $e) {
							   echo "Document storage failed : ".$e->getMessage()."<BR>\n";
							}
	
	
	**/
	
	$sql2 = "update tbl_booking set status='".$col6.
		"' , modified_by='".$col9.
		"' , date_modified='".$dt.
		"' where id='".$doc1."'";

			
	

			if ($conn->query($sql2) === TRUE) {
				
				 header("location:".$filepath);
			}
			else{
				echo "Error: " . $sql . "<br>" . $conn->error;
				
			}
	
}

}


if(isset($_POST['clicked1'])){ //delete
	$selected_val = key($_POST['clicked1']); 

$check=1;
if ($check=1)
{
	//$col1=$_POST['col1_'.$selected_val];
	//$col2=$_POST['col2_'.$selected_val];
	//$col3=$_POST['col3_'.$selected_val];
	$doc1=$_POST['doc_'.$selected_val];
	/**$client = new couchClient($url,$db);
	$doc = $client->getDoc($doc1);
	try {
   $client->deleteDoc($doc);
   header("location:".$filepath);
	} 
	catch (Exception $e) {
	echo "Document storage failed : ".$e->getMessage()."<BR>\n";
	}
		 
	**/
	$sql2 = "delete from tbl_booking where id='".$doc1."'";

			
	

			if ($conn->query($sql2) === TRUE) {
				
				 header("location:".$filepath);
			}
			else{
				echo "Error: " . $sql . "<br>" . $conn->error;
				
			}		
	
}
}

if(isset($_POST['clicked2'])){
	$add = key($_POST['clicked2']); 
	//$add1=$_POST['add1_'.$add];
	
	$add3=$_POST['add3_'.$add];
	$add4=$_POST['add4_'.$add];
	$add5=$_POST['add5_'.$add];
	$add6=$_POST['add6_'.$add];
	$add7=$_POST['add7_'.$add];
	//dd8=$_POST['add8_'.$add];
	$add9=$_POST['add9_'.$add];
	//dd10_POST['add10.$add];
	
	echo "</br>".$add;
		//echo "</br>first1".$add1;
			echo "</br>first12".$add3;
				echo "</br>first13".$add4;
					echo "</br>first12".$add5;
				echo "</br>first13".$add6;
					echo "</br>first12".$add7;
				echo "</br>first13".$add9;
				//	echo "</br>first12".$add10;
				//echo "</br>first13".$add3;

	$check=45;
	
	
	
	
				
	
	
	
	
}

}


?>


<head>
<title>Test this</title>
</head>
<body>



</body>
</html>