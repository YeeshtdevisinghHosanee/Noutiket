-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 06, 2020 at 04:18 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_queue1`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id` int(11) NOT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `branchid` int(11) NOT NULL,
  `level` varchar(1) NOT NULL,
  `date_created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `username`, `password`, `name`, `branchid`, `level`, `date_created`) VALUES
(1, 'admin', '5f4dcc3b5aa765d61d8327deb882cf99', 'firstuser', 1, 'S', '2020-06-06 17:30:09');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_booking`
--

CREATE TABLE `tbl_booking` (
  `id` int(11) NOT NULL,
  `currentcounter` int(11) NOT NULL,
  `time_assisted` time NOT NULL,
  `branchid` int(11) NOT NULL,
  `branch_name` varchar(50) NOT NULL,
  `status` varchar(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `modified_by` varchar(50) NOT NULL,
  `ticketnumber` varchar(50) NOT NULL,
  `clientid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_branch`
--

CREATE TABLE `tbl_branch` (
  `id` int(11) NOT NULL,
  `bname` varchar(50) NOT NULL,
  `businessid` int(11) NOT NULL,
  `location` varchar(100) NOT NULL,
  `date_created` datetime NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_branch`
--

INSERT INTO `tbl_branch` (`id`, `bname`, `businessid`, `location`, `date_created`, `date_modified`) VALUES
(1, 'School1', 1, 'Location1', '2020-06-06 17:30:08', '2020-06-06 17:35:37'),
(2, 'School2', 1, 'loca', '2020-06-06 17:35:51', '0000-00-00 00:00:00'),
(3, 'Agro1', 2, 'f', '2020-06-06 17:37:31', '0000-00-00 00:00:00'),
(4, 'Agro2', 2, 'd', '2020-06-06 17:38:03', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_business`
--

CREATE TABLE `tbl_business` (
  `id` int(11) NOT NULL,
  `bname` varchar(50) NOT NULL,
  `location` varchar(50) NOT NULL,
  `date_created` datetime NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_business`
--

INSERT INTO `tbl_business` (`id`, `bname`, `location`, `date_created`, `date_modified`) VALUES
(1, 'MiniEdu', 'location1', '2020-06-06 17:30:08', '2020-06-06 17:35:18'),
(2, 'MiniAgro', 'address2', '2020-06-06 17:32:58', '2020-06-06 17:35:12');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_client`
--

CREATE TABLE `tbl_client` (
  `id` int(255) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `date_created` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_client`
--

INSERT INTO `tbl_client` (`id`, `username`, `password`, `fname`, `lname`, `date_created`) VALUES
(1, 'test1', '5f4dcc3b5aa765d61d8327deb882cf99', 'Lina', 'Ram', '2020-06-06');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_counter`
--

CREATE TABLE `tbl_counter` (
  `id` int(11) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `branchid` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_counter`
--

INSERT INTO `tbl_counter` (`id`, `fname`, `lname`, `branchid`, `date_create`, `date_modified`) VALUES
(1, 'lina', 'rama', 1, '2020-06-06 17:31:14', '0000-00-00 00:00:00'),
(2, 'roshni', 'rita', 1, '2020-06-06 17:31:23', '0000-00-00 00:00:00'),
(3, 'Lina', 'Roshni', 3, '2020-06-06 17:40:40', '0000-00-00 00:00:00'),
(4, 'Jimmy', 'JIm', 2, '2020-06-06 17:41:16', '0000-00-00 00:00:00'),
(5, 'Rakesh', 'rack', 4, '2020-06-06 17:42:16', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_counter_criteria`
--

CREATE TABLE `tbl_counter_criteria` (
  `id` int(11) NOT NULL,
  `branchid` int(11) NOT NULL,
  `bcnum` int(11) NOT NULL,
  `maxserved` int(11) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `currenttime` time NOT NULL,
  `counter` int(11) NOT NULL,
  `date_created` datetime NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_counter_criteria`
--

INSERT INTO `tbl_counter_criteria` (`id`, `branchid`, `bcnum`, `maxserved`, `start_time`, `end_time`, `currenttime`, `counter`, `date_created`, `date_modified`) VALUES
(1, 1, 1, 30, '09:00:00', '10:00:00', '09:00:00', 1, '2020-06-06 17:31:30', '2020-06-06 17:50:45'),
(2, 1, 1, 30, '10:00:00', '11:00:00', '10:00:00', 1, '2020-06-06 17:31:45', '2020-06-06 17:51:17'),
(3, 1, 1, 30, '11:00:00', '12:00:00', '11:00:00', 1, '2020-06-06 17:46:49', '2020-06-06 17:51:35'),
(4, 1, 1, 30, '13:00:00', '14:00:00', '13:00:00', 1, '2020-06-06 17:47:21', '2020-06-06 17:52:01'),
(5, 1, 1, 30, '16:00:00', '16:00:00', '16:00:00', 1, '2020-06-06 17:48:54', '2020-06-06 17:52:47'),
(6, 1, 2, 20, '09:00:00', '10:00:00', '09:00:00', 2, '2020-06-06 17:54:26', '2020-06-06 17:57:52'),
(7, 1, 2, 20, '10:00:00', '11:00:00', '10:00:00', 2, '2020-06-06 17:55:37', '2020-06-06 17:57:54'),
(8, 2, 4, 20, '09:00:00', '16:00:00', '09:00:00', 1, '2020-06-06 17:57:41', '2020-06-06 17:59:20'),
(14, 1, 3, 5, '09:00:00', '16:00:00', '09:00:00', 1, '2020-06-06 18:02:45', '2020-06-06 18:04:40'),
(15, 1, 3, 5, '09:00:00', '16:00:00', '09:00:00', 2, '2020-06-06 18:03:03', '2020-06-06 18:05:02'),
(16, 3, 1, 5, '09:00:00', '16:00:00', '09:00:00', 3, '2020-06-06 18:03:18', '2020-06-06 18:05:17');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_holiday`
--

CREATE TABLE `tbl_holiday` (
  `id` int(11) NOT NULL,
  `hol_date` date NOT NULL,
  `date_created` datetime NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_holiday`
--

INSERT INTO `tbl_holiday` (`id`, `hol_date`, `date_created`, `date_modified`) VALUES
(1, '2020-08-15', '0000-00-00 00:00:00', '2020-06-06 18:16:43'),
(2, '2020-08-23', '2020-06-03 19:30:55', '2020-06-06 18:16:58'),
(3, '2020-11-02', '2020-06-03 19:31:25', '2020-06-06 18:17:12'),
(4, '2020-11-14', '2020-06-06 18:17:35', '0000-00-00 00:00:00'),
(5, '2020-12-25', '2020-06-06 18:17:54', '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`),
  ADD KEY `branchid` (`branchid`);

--
-- Indexes for table `tbl_booking`
--
ALTER TABLE `tbl_booking`
  ADD PRIMARY KEY (`id`),
  ADD KEY `branchid` (`branchid`);

--
-- Indexes for table `tbl_branch`
--
ALTER TABLE `tbl_branch`
  ADD PRIMARY KEY (`id`),
  ADD KEY `businessid` (`businessid`);

--
-- Indexes for table `tbl_business`
--
ALTER TABLE `tbl_business`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_client`
--
ALTER TABLE `tbl_client`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_counter`
--
ALTER TABLE `tbl_counter`
  ADD PRIMARY KEY (`id`),
  ADD KEY `branchid` (`branchid`);

--
-- Indexes for table `tbl_counter_criteria`
--
ALTER TABLE `tbl_counter_criteria`
  ADD PRIMARY KEY (`id`),
  ADD KEY `branchid` (`branchid`),
  ADD KEY `c_criteriacounter` (`bcnum`);

--
-- Indexes for table `tbl_holiday`
--
ALTER TABLE `tbl_holiday`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_booking`
--
ALTER TABLE `tbl_booking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_branch`
--
ALTER TABLE `tbl_branch`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_business`
--
ALTER TABLE `tbl_business`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_client`
--
ALTER TABLE `tbl_client`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_counter`
--
ALTER TABLE `tbl_counter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_counter_criteria`
--
ALTER TABLE `tbl_counter_criteria`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tbl_holiday`
--
ALTER TABLE `tbl_holiday`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD CONSTRAINT `c_adminusers` FOREIGN KEY (`branchid`) REFERENCES `tbl_branch` (`id`) ON UPDATE NO ACTION;

--
-- Constraints for table `tbl_booking`
--
ALTER TABLE `tbl_booking`
  ADD CONSTRAINT `c_booking` FOREIGN KEY (`branchid`) REFERENCES `tbl_branch` (`id`) ON UPDATE NO ACTION;

--
-- Constraints for table `tbl_branch`
--
ALTER TABLE `tbl_branch`
  ADD CONSTRAINT `c_businessid` FOREIGN KEY (`businessid`) REFERENCES `tbl_business` (`id`);

--
-- Constraints for table `tbl_counter`
--
ALTER TABLE `tbl_counter`
  ADD CONSTRAINT `tbl_counter_ibfk_1` FOREIGN KEY (`branchid`) REFERENCES `tbl_branch` (`id`) ON UPDATE NO ACTION;

--
-- Constraints for table `tbl_counter_criteria`
--
ALTER TABLE `tbl_counter_criteria`
  ADD CONSTRAINT `c_criteria` FOREIGN KEY (`branchid`) REFERENCES `tbl_branch` (`id`),
  ADD CONSTRAINT `c_criteriacounter` FOREIGN KEY (`bcnum`) REFERENCES `tbl_counter` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
