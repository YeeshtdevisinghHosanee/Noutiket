<?php
require_once 'qa_connection.php';

//to manage business data


session_start() ;
$var_todate=date("Y-m-d H:i:s");
$g_uid=$_SESSION['username'];
//$g_bid=$_SESSION['password'];
$name=$_SESSION['name'] ;
$g_bid= $_SESSION['branchid'];
 //echo "ss".$g_uid;
if ($g_uid<>"")
{
	$_SESSION['username']=$g_uid ;
		// $_SESSION['password'] =$g_password;
		 $_SESSION['name'] =$name;
		 	 $_SESSION['branchid'] =$g_bid;

echo "User:".$g_uid."   BranchID:".$g_bid;
$filepath="qa_admin_businessid.php";
$check=0;
$selected_val=0;

$db="tbl_branch";
if(isset($_POST['clicked'])){
	$selected_val = key($_POST['clicked']); 
$arra1=explode('-',$selected_val);
$check=1;
if ($check=1)
{
	//$col1=$_POST['col1_'.$selected_val];
	$col2=$_POST['col2_'.$arra1[0].'-'.$arra1[1]];
	$col3=$_POST['col3_'.$arra1[0].'-'.$arra1[1]];
	$doc1=$_POST['doc_'.$arra1[0].'-'.$arra1[2]];
	
	
	
	$sql2 = "update tbl_business set bname='".$col2."' , location='".$col3."',date_modified='".$var_todate."' where id='".$doc1."'";

			
	

			if ($conn->query($sql2) === TRUE) {
				
				 header("location:".$filepath);
			}
			else{
				echo "Error: " . $sql2 . "<br>" . $conn->error;
				
			}
	
	
	
}

}


if(isset($_POST['clicked1'])){ //delete
	$selected_val = key($_POST['clicked1']); 

$check=1;
if ($check=1)
{
	//$col1=$_POST['col1_'.$selected_val];
	//$col2=$_POST['col2_'.$selected_val];
	//$col3=$_POST['col3_'.$selected_val];
	$doc1=$_POST['doc_'.$selected_val];
	/**$client = new couchClient($url,$db);
	$doc = $client->getDoc($doc1);
	try {
   $client->deleteDoc($doc);
   header("location:".$filepath);
	} 
	catch (Exception $e) {
	echo "Document storage failed : ".$e->getMessage()."<BR>\n";
	}
	**/	 
	
	$sql2 = "delete from tbl_business where id='".$doc1."'";

			
	

			if ($conn->query($sql2) === TRUE) {
				
				 header("location:".$filepath);
			}
			else{
				echo "Error: " . $sql2 . "<br>" . $conn->error;
				
			}
	
	
}
}

if(isset($_POST['clicked2'])){
	$add = key($_POST['clicked2']); 
	//$add1=$_POST['add1_'.$add];
	$add2=$_POST['add2_'.$add];
	$add3=$_POST['add3_'.$add];
	

	
	
	$sql3 = "INSERT INTO tbl_business (bname,location,date_created)  VALUES ('$add2','$add3','$var_todate')";

			
		//$result1 = mysqli_query($conn, $sql1);

			if ($conn->query($sql3) === TRUE) {
		
			//echo "eee".$g_check1;
	
			
	
						 header("location:".$filepath);
			}	
			
			else{
				echo "Error: " . $sql3 . "<br>" . $conn->error;
				
			}
	
	
	
	
	
	
	
}

}


?>


<head>
<title>Test this</title>
</head>
<body>



</body>
</html>