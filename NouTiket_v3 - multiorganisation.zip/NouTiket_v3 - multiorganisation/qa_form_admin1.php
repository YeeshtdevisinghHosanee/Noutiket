<?php
require_once 'qa_connection.php';

//if(isset($_POST['submit'])){
//echo "ÿes";

$bname=$_POST['txt_bname'];

$counter=$_POST['txt_counter'];
$maxserved=$_POST['txt_maxserved'];
$t_stime=$_POST['txt_stime'];
$t_etime=$_POST['txt_etime'];
$t_text=$_POST['txt_text'];
//date_default_timezone_set('Asia/Dubai');
$date = date("Y/m/d");
	$dt=date("Y/m/d h:i:s");
	
	echo "<br/>".$bname;
					echo "<br/>".$counter;
					echo "<br/>".$maxserved;
						echo "<br/>".$t_stime;
					echo "<br/>".$t_etime;
					echo "<br/>".$t_text;
	
	
	//echo $dt."GG";
//$sql = "INSERT INTO tbl_counter (branch_name,counter,num_staff,max_served,start_time,end_time,currenttime,ticketing_text,date_created) 
//VALUES ('$bname', '$counter', 1,'$maxserved','$t_stime','$t_etime','$t_stime','$t_text','$dt')";

//if ($conn->query($sql) === TRUE) {
    
	
	//$sql = "select * from tbl_counter where branch_name='".$bname."' and date_created='".$dt."'";
	//and date_created='".$dt."'";
			//	$result = mysqli_query($conn, $sql);
				// CHECK THE QUERY WAS SUCCESSFUL
				//$idr ="";
				//if ($result) 
				//{
					//echo "cope";
					//while($row = mysqli_fetch_array($result)) 
					//{
					//	 $idr   =   $row["ID"];
						 //echo "ffff". $idr;
					//	 if(!is_dir($idr))
					//	 {
					//	 mkdir($idr, 777, true);
					//	 }
					//}
						//echo $idr."idr";
				

				

				//}
	
	
	
	//echo "New record created successfully";
	
	
	
//} else {
   // echo "Error: " . $sql . "<br>" . $conn->error;
//}

//$conn->close();

//}

				$current_cid=0;
				$g_cid=0;
				$db="tbl_counter_criteria";
				
				$client = new couchClient($url,$db);
				
				$all_records = $client->getAllDocs();
				//echo '<select size="1" style="width:400px" width="10" name="txt_bname" id="txt_bname">';
				
				foreach ( $all_records->rows as $row ) {
				   
					$doc = CouchDocument::getInstance($client,$row->id);
					//print_r ($doc);
					$user_bid=$doc->id;
					if ($user_bid>$g_cid)
					{
						$g_cid=$user_bid;
					}
					echo "<br/>".$user_bid;

				 }
				 $current_cid=$g_cid+1;
				 
				 
				 // ('$bname', '$counter', 1,'$maxserved','$t_stime','$t_etime','$t_stime','$t_text','$dt')";
			//	$doc = new couchDocument($client);
				//$doc->set( array('_id'=>$current_cid ,'branchid'=>'$bname','bcnum'=>'$counter','maxserved'=>'$maxserved','start_time'=>'$t_stime','end_time'=>'$t_etime','date_created'=>'$dt') ); //create a document and store it in the database
			    
			//	$doc->_id=$current_cid;
			
			$prop = new stdClass();
$prop->id = $current_cid;
$prop->branchid = $bname;
$prop->bcnum = $counter;
$prop->maxserved = $maxserved;
$prop->start_time = $t_stime;
$prop->end_time = $t_etime;
$prop->current_time = $t_stime;
$prop->counter = $counter;
$prop->date_created = $dt;


$doc = new CouchDocument($client);
if ($doc->set ( $prop ))
{
	
	
	echo "Insertion completed successfully";
}
else
{
	echo "could not insert record in database";
	
}	






?>

<html>




</html>