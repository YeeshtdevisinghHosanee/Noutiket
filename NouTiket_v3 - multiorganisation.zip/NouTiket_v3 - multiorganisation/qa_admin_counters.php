<?php
require_once 'qa_connection.php';
session_start() ;
$g_uid=$_SESSION['username'];
//$g_bid=$_SESSION['password'];
$name=$_SESSION['name'] ;
$g_bid= $_SESSION['branchid'];
 //echo "ss".$g_uid;

	$_SESSION['username']=$g_uid ;
		// $_SESSION['password'] =$g_password;
		 $_SESSION['name'] =$name;
		 	 $_SESSION['branchid'] =$g_bid;

echo "User:".$g_uid."   BranchID:".$g_bid;

echo '<font size="2" color="blue" ><p align="right"><a href="qa_mainmenu1.php">Back to Main Menu</a></p></font></br>';
echo '<h1>Update, delete and add Counters</h1>';

$docid=array();
$column1=array();
$column2=array();
$column3=array();
$column4=array();
$column5=array();
$column6=array();

$crec=0;
$g_check=0;
$db="tbl_counter";
/**$client = new couchClient($url,$db);
$all_records = $client->getAllDocs();
 foreach ( $all_records->rows as $row ) {
  
    $doc = CouchDocument::getInstance($client,$row->id);
	
	$user_bid=$doc->_id;
	$bid=$doc->id;
	$user_branchname=$doc->fname;
	$user_businessid=$doc->lname;

		$docid[$crec]=$user_bid;
		$column1[$crec]=$bid;
		$column2[$crec]=$user_branchname;
		$column3[$crec]=$user_businessid;
		
		$crec=$crec+1;
	
   }
**/

 $sql="select * from tbl_counter  order by date_create,date_modified desc";
$result = mysqli_query($conn, $sql);

			if ($result) {
				//  echo "yes";
				// while($row = mysqli_fetch_array($result)) {
				
					//$g_criteriaid=$row["id"];
					//echo "ff".$g_criteriaid;
				 //}
				$count=0;
			  while($row = mysqli_fetch_array($result)) {
					
					
					$docid[$crec]=$row["id"];
					$column1[$crec]=$row["id"];
					$column2[$crec]=$row["fname"];
					$column3[$crec]=$row["lname"];
					$column4[$crec]=$row["date_create"];
					$column5[$crec]=$row["date_modified"];
					$column6[$crec]=$row["branchid"];
					
					$crec=$crec+1;
					
			  }
			}




echo '</br></br></br></br>';
echo '<form action="qa_admin_counter1s.php"  method="post">';
echo '<table>';
echo '<tr>';
echo '<td>';
echo '<table border="1"';


echo '<th><td>Counter ID</td><td>First Name</td><td>Last Name</td><td>Date Created</td><td>Date Modified</td></td><td>BranchID</td><td>Update</td><td>Delete</td></th>';
for ($x = 0; $x < $crec; $x++) {
    //echo "The number is: $x <br>";
	
	
	echo '<tr>';
	echo '<td>'.'<input type="text"  name="doc_'.$x.'-'.$docid[$x].'" id="doc_'.$x.'-'.$docid[$x].'" value="'.$docid[$x].'" </td>';
	//echo '<td>'.'<input type="text" disabled name="col1_'.$x.'-'.$column1[$x].'-'.$column1[$x].'" id="col1_'.$x.'" value="'.$column1[$x].'" </td>';
	echo '<td>'.'<input type="text" name="col2_'.$x.'-'.$column1[$x].'" id="col1_'.$x.'-'.$column1[$x].'" value="'.$column2[$x].'" </td>';
	echo '<td>'.'<input type="text" name="col3_'.$x.'-'.$column1[$x].'" id="col1_'.$x.'-'.$column1[$x].'" value="'.$column3[$x].'" </td>';
	
		echo '<td>'.'<input disabled type="text" name="col4_'.$x.'-'.$column1[$x].'" id="col1_'.$x.'-'.$column1[$x].'" value="'.$column4[$x].'" </td>';
	echo '<td>'.'<input disabled type="text" name="col5_'.$x.'-'.$column1[$x].'" id="col1_'.$x.'-'.$column1[$x].'" value="'.$column5[$x].'" </td>';
    echo '<td>'.'<input  type="text" name="col6_'.$x.'-'.$column1[$x].'" id="col1_'.$x.'-'.$column1[$x].'" value="'.$column6[$x].'" </td>';
	
	
	echo '<td>'.'<input type="submit" name="clicked['.$x.'-'.$column1[$x].'-'.$docid[$x].']" id="butu_'.$x.'-'.$column1[$x].'" value="'.'update'.'" </td>';
	echo '<td>'.'<input type="submit" name="clicked1['.$x.'-'.$docid[$x].']" id="butd_'.$x.'-'.$docid[$x].'" value="'.'Delete'.'" </td>';
	echo '</tr>';
}



echo '</table>';
echo '</td>';
echo '<td>';
echo '<table border="1"';
echo '<th><td>Counter ID</td><td>First Name</td><td>Last Name</td><td>Branch</td><td>add</td></th>';
for ($x1 = 0; $x1 < 1; $x1++) {
    //echo "The number is: $x1 <br>";
	
	
	echo '<tr>';
	echo '<td>'.'<input type="text"  disabled name="add1_'.$x1.'" id="add1_'.$x1.'" value="automatic" </td>';
	echo '<td>'.'<input type="text"  name="add2_'.$x1.'" id="add1_'.$x1.'" value="" </td>';
	echo '<td>'.'<input type="text"  name="add3_'.$x1.'" id="add1_'.$x1.'" value="" </td>';
	//echo '<td>'.'<input type="text"  name="add4_'.$x1.'" id="add1_'.$x1.'" value="" </td>';
		echo '<td><select size="1" style="width:400px" width="10" name="add4_'.$x1.'" id="add4_'.$x1.'">';
		
	 $sql="select * from tbl_branch  ";
			$result = mysqli_query($conn, $sql);

			if ($result) {
				//  echo "yes";
				// while($row = mysqli_fetch_array($result)) {
				
					//$g_criteriaid=$row["id"];
					//echo "ff".$g_criteriaid;
				 //}
				$count=0;
			  while($row = mysqli_fetch_array($result)) {
					
					
					
					$user_bid=$row["id"];
					
					$user_branchname=$row["bname"];
				
					
			 
			

				
				
				echo '<option  value="'.$user_bid.'">'.$user_branchname.'</option>';
				 }
			}
				//echo '</select>';
			
		echo	'</select></td>';
	
	
	
	
	
	
	
	echo '<td>'.'<input type="submit" name="clicked2['.$x1.']" id="butu_'.$x1.'" value="'.'Add'.'" </td>';

	echo '</tr>';
}

echo '</table>';
echo '</td>';
echo '</tr>';
echo '</table>';
echo '</form>';

//http://localhost/queueapp/testapp/qa_admin_branch.php














?>


<head>
<title>Test this</title>
</head>
<body>



</body>
</html>