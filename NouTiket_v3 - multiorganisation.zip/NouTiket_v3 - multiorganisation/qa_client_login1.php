<?php
require_once 'qa_connection.php';
session_start() ;

 $cid=$_SESSION['cid'] ;
 $user=  $_SESSION['username'] ;
 $fname=  $_SESSION['fname'] ;
	 
	



	$_SESSION['cid'] = $cid;
	$_SESSION['username']=$user ;
	$_SESSION['fname'] = $fname;
	

	 
	 //$conn->close();
	
?>

<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="a.css">
<style>
body {
  font-family: "Lato", sans-serif;
}

/* Fixed sidenav, full height */
.sidenav {
  height: 100%;
  width: 200px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #2ECC71;
  overflow-x: hidden;
  padding-top: 20px;
}

/* Style the sidenav links and the dropdown button */
.sidenav a, .dropdown-btn {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 20px;
  color: #818181;
  display: block;
  border: none;
  background: none;
  width: 100%;
  text-align: left;
  cursor: pointer;
  outline: none;
}

/* On mouse-over */
.sidenav a:hover, .dropdown-btn:hover {
  color: #f1f1f1;
}

/* Main content */
.main {
  margin-left: 200px; /* Same as the width of the sidenav */
  font-size: 20px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

/* Add an active class to the active dropdown button */
.active {
  background-color: green;
  color: white;
}

/* Dropdown container (hidden by default). Optional: add a lighter background color and some left padding to change the design of the dropdown content */
.dropdown-container {
  display: none;
  background-color: #262626;
  padding-left: 8px;
}

/* Optional: Style the caret down icon */
.fa-caret-down {
  float: right;
  padding-right: 8px;
}

/* Some media queries for responsiveness */
@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>
</head>
<body>

<div class="sidenav">
  
  <?php
    $chk1=0;
   if ($user<>"")
   {
	

		$dt1=date("Y-m-d");	
		$sql = "select * from tbl_holiday where hol_date='".$dt1."'"; // check holidays
		  $result = mysqli_query($conn, $sql);
		
		if ($result) 
		{
			
			$x=0;
		  while($row = mysqli_fetch_array($result)) 
		  {
			   
				$chk1=1;
		  }

	

			$curda=date("w");
			if ($curda==0 || $curda==5) // check if day is on weekend
			{

			$chk1=2;

			}


  
  
			if ($chk1==0)  // if no weekend and no publiic holiday, then display business data
			{

			 $sql = "select * from tbl_business";
			  $result = mysqli_query($conn, $sql);
			   if ($user<>"")
				{
					if ($result) 
					{
					
				
					  while($row = mysqli_fetch_array($result)) 
					  {
							$businessname  =  $row["bname"];
							
			
						echo '<a href="qa_client_login2.php?busid='.$row["id"].'&busname='.$businessname.'">'.$businessname.'</a>';
						// $_SESSION['busid']=  $row["id"]; ;
						
				
					

					  }
					}
				}
			}
		}
	 }
  ?>
  
</div>

<div class="main">
 
  <p>
<?php



 if ($user<>"")
	 {
 echo '<font size="3" color="blue" ><p align="right"><a href="qa_reset_client.php">Reset Password</a>      <a href="qa_client_login.php">Sign out</a></p></font></br>';


	 echo  ''."Dear ". $fname.", ";
	 }

if ($chk1<>0)
{
	echo '<br><br>We are closed.</br>';
	
}

if ($chk1==0)
{
	echo '</br></br>The following instructions will guide you through the e-ticketing system.</br>';
	echo '<p>1.  Use your mobile phone</p>';
	echo '2.  Select an institution</p>';
	echo '3.  Select an outlet</p>';
	echo '4.  Check your available time</p>';
	echo '5.  Click on the counter of your choice </p>';
	echo '6.  Click on download </p>';
	echo '7.  Click on save as on your mobile phone </p>';
	echo '8.  Open the file </p>';
	echo '9.  Verify that your e-ticket is well saved on your mobile phone. (files->download folder) </p>';
	echo '10. Present your e-ticket on your mobile to the counter, from one meter distance </p>';
}


$conn->close();	
?>

</p>
  <p></p>
  <p></p>
</div>

<script>
/* Loop through all dropdown buttons to toggle between hiding and showing its dropdown content - This allows the user to have multiple dropdowns without any conflict */
var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 0; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
  this.classList.toggle("active");
  var dropdownContent = this.nextElementSibling;
  if (dropdownContent.style.display === "block") {
  dropdownContent.style.display = "none";
  } else {
  dropdownContent.style.display = "block";
  }
  });
}
</script>

</body>
</html> 