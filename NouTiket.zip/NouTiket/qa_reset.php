<?php
require_once 'qa_connection.php';
$dt=date("Y-m-d H:i:s");
session_start() ;
$g_uid=$_SESSION['username'];
//$g_bid=$_SESSION['password'];
$name=$_SESSION['name'] ;
$g_bid= $_SESSION['branchid'];
 //echo "ss".$g_uid;

	$_SESSION['username']=$g_uid ;
		// $_SESSION['password'] =$g_password;
		 $_SESSION['name'] =$name;
		 	 $_SESSION['branchid'] =$g_bid;

echo '<font size="2" color="blue" ><p align="right"><a href="qa_mainmenu.php">Back to Main Menu</a></p></font></br>';
 $filepath="qa_admin_mainmenu.php";
if(isset($_POST['submit'])){
$g_newpassword=$_POST['txt_new'];
$g_password=$_POST['txt_bname'];
$g_check=0;
$g_bid=0;
$g_docid="";

//date_default_timezone_set('Asia/Dubai');
$date = date("Y/m/d");
$dt=date("Y/m/d h:i:s");

$temp="";
$bname="";
$result="";

$db="tbl_login";
/** $client = new couchClient($url,$db);
  $all_singers = $client->getAllDocs();
  foreach ( $all_singers->rows as $row ) {
   
    $doc = CouchDocument::getInstance($client,$row->id);
	
	$user_id=$doc->_id;
	$user_name=$doc->username;
	$user_password=$doc->password;
	$user_branch=$doc->branchid;
  
	//echo "<br/>".$user_id;
	//echo "<br/>".$user_name;
	//echo "<br/>".$user_password;
	//echo "<br/>".$user_branch;
	
	if ($user_name==$g_uid)
	{
		
		
		if ($user_password==$g_password)
		{
			$g_check=9;
			$g_bid=$user_branch;
			$g_docid=$user_id;
			
			$client3 = new couchClient($url,$db);
			$doca = $client3->getDoc($user_id);
						
		
			$doca->password =$g_newpassword;
			try {
							   $client3->storeDoc($doca);
							  echo "</br>Password changed successfully.";
							  
			} catch (Exception $e) {
							   echo "</br>Error: Document storage failed : ".$e->getMessage()."<BR>\n";
			}		
					
					
					
							
							
			
			
		}
		
		
	}	
	
	
   }**/
   
   
   $sql="select * from tbl_admin";
$result = mysqli_query($conn, $sql);

			if ($result) {
				//  echo "yes";
				// while($row = mysqli_fetch_array($result)) {
				
					//$g_criteriaid=$row["id"];
					//echo "ff".$g_criteriaid;
				 //}
				$count=0;
			  while($row = mysqli_fetch_array($result)) {
					$g_check1=2;
					$username=$row["username"];
					$password=$row["password"];
					$g_branchid=$row["branchid"];
					$level=$row["level"];
					$id=$row["id"];
					
					if ($username==$g_uid)
					{
						if ($password==$g_password)
						{
						//	if ($level=="S")
						//{
							
							
							$sql2 = "update tbl_admin set password='".$g_newpassword.
						
							"' where id='".$id."'";

								
						

								if ($conn->query($sql2) === TRUE) {
									
									 $g_check=9;
								}
								
	
						
							
							
						
						//}
						}	
					
						
						
						
					}	
					
			  }
			}




 
 if ($g_check==9)
 {
	 //header("Location: qa_mainmenu.php?uid=".$g_uid."&bid=".$g_bid."&docid=".$g_docid);
	 echo "</br>Password changed successfully.";
	 
	 
 }

else
{
	
	echo "</br>Error: Username/Password not found.Try again";
}












}






//$conn->close();

//}
?>

<html>
 <form method="POST">
<font size="20" color="blue"><center><a>Reset Admin</a></center></font></br>
	<table>
	
	
		<tr>
				<td>Old Password</td>
				<td><input  style="width:200px"       type="password" id="txt_bname" name="txt_bname"      /></td>
		
		</tr>
		
		
		<tr>
				<td>New Password</td>
				<td><input style="width:200px" "type="password" id="txt_new" name="txt_new"       /></td>
		
		</tr>
		
		
		
	
	
		<tr>
				<td><input type="submit"  id="submit" name="submit"   onclick="func_a()"/></td>
		
		</tr>
	
	</table>




</form>

<div id="div_response" style="display:inline">

</div>



</html>