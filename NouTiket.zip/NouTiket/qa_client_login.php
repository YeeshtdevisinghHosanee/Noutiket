<?php
require_once 'qa_connection.php';
session_start() ;

if(isset($_POST['submit'])){
$g_username=trim($_POST['txt_id']);
$g_password=trim($_POST['txt_bname']);
//echo "password".$g_password."fff";
$g_bid=0;
$g_docid="";

////date_default_timezone_set('Asia/Dubai');
$date = date("Y/m/d");
$dt=date("Y/m/d h:i:s");

$g_check=0;
   $sid=0;
    $name="";
	$studentid="";
   $sql = "select * from tbl_client";
  $result = mysqli_query($conn, $sql);
if ($result) {
	
	$count=0;
  while($row = mysqli_fetch_array($result)) {
        $username  =   trim($row["username"]);
        $password1   =   trim($row["password"]);
		// $sid   =   $row["password"];
		 $lname   =   $row["lname"];
		 $fname   =   $row["fname"];
		 $cid   =   $row["id"];
		
		if ($g_username==$username)
		{ //echo "</br>".$password1."check33".$g_password;
			if ($password1==$g_password)
			{
				
			$g_check=9;
			
			$_SESSION['username'] = $g_username;
			$_SESSION['password']=$password ;
			//$_SESSION['sid'] = $sid;
			$_SESSION['cid'] = $cid;
			$_SESSION['lname'] = $lname;
			$_SESSION['fname'] = $fname;
			//  echo "retrieved2".$sid."ff";
			}
		}		
	

  }


 if ($g_check==9)
 {
	
		//header("location:qa_client_login1.php?username=".$g_username."&password=".$password."&sid=".$sid."&studentid=".$studentid."&name=".$name);
			
		// echo  '<font size="3" color="black">'."Hello, ". $password ."</font> ";
		header("location:qa_client_login1.php");
	
 }
 else{
	 
	 echo "Username and password not found.";
	 
 }

	


}




}






//$conn->close();

//}
?>

<html>
 <form method="POST">
<font size="20" color="blue"><center><a>Client Login Page</a></center></font></br>
	<table>
	
	
		<tr>
				<td>ID</td>
				<td><input style="width:200px" "type="text" id="txt_id" name="txt_id"       /></td>
		
		</tr>
		<tr>
				<td>Password</td>
				<td><input  style="width:200px"       type="password" id="txt_bname" name="txt_bname"      /></td>
		
		</tr>
		
		
		
	
	
		<tr>
				<td><input type="submit"  id="submit" name="submit"   /></td>
		
		</tr>
	
	</table>




</form>

<div id="div_response" style="display:inline">

</div>



</html>